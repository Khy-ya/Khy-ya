export function nFmt(n: number | null | undefined): string {
  const v = Number(n ?? 0);
  if (v >= 1_000_000) return (v / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (v >= 1_000) return (v / 1_000).toFixed(1).replace(/\.0$/, "") + "k";
  return String(v);
}
export function timeAgo(iso: string | Date): string {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  const s = Math.floor((Date.now() - d.getTime()) / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60); if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60); if (h < 24) return `${h}h`;
  const dd = Math.floor(h / 24); if (dd < 7) return `${dd}d`;
  const w = Math.floor(dd / 7); if (w < 5) return `${w}w`;
  const mo = Math.floor(dd / 30); if (mo < 12) return `${mo}mo`;
  return `${Math.floor(dd / 365)}y`;
}
export function levelFromXp(xp: number): { level: number; progress: number; next: number } {
  // 100 * level^1.5 xp per level cumulative
  let level = 1;
  let need = 100;
  let acc = need;
  while (xp >= acc) { level++; need = Math.floor(100 * Math.pow(level, 1.5)); acc += need; }
  const prevAcc = acc - need;
  return { level, progress: xp - prevAcc, next: need };
}
