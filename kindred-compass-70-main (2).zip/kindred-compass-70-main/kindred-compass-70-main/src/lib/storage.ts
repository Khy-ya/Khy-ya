import { supabase } from "@/integrations/supabase/client";

const CACHE = new Map<string, string>();

/**
 * Get a long-lived signed URL for a private-bucket object.
 * Falls back to the raw storage URL if signing fails (unlikely).
 */
export async function signedUrl(bucket: string, path: string, expiresIn = 60 * 60 * 24 * 365): Promise<string> {
  if (!path) return "";
  const key = `${bucket}/${path}`;
  const cached = CACHE.get(key);
  if (cached) return cached;
  const { data } = await supabase.storage.from(bucket).createSignedUrl(path, expiresIn);
  const url = data?.signedUrl ?? "";
  if (url) CACHE.set(key, url);
  return url;
}

export async function uploadImage(bucket: string, userId: string, file: File): Promise<{ path: string; url: string }> {
  const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, { cacheControl: "3600", upsert: false, contentType: file.type });
  if (error) throw error;
  const url = await signedUrl(bucket, path);
  return { path, url };
}
