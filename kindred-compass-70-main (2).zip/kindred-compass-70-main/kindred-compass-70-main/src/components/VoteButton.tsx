import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Heart } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { cn } from "@/lib/utils";
import { nFmt } from "@/lib/format";

export function VoteButton({ postId, initialCount, size = "sm" }: { postId: string; initialCount: number; size?: "sm" | "lg" }) {
  const { user } = useAuth();
  const nav = useNavigate();
  const [count, setCount] = useState(initialCount);
  const [voted, setVoted] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => setCount(initialCount), [initialCount]);

  useEffect(() => {
    if (!user) { setVoted(false); return; }
    supabase.from("votes").select("post_id").eq("post_id", postId).eq("user_id", user.id).maybeSingle()
      .then(({ data }) => setVoted(!!data));
  }, [user, postId]);

  useEffect(() => {
    const ch = supabase.channel(`post-${postId}-votes`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "votes", filter: `post_id=eq.${postId}` }, () => setCount(c => c + 1))
      .on("postgres_changes", { event: "DELETE", schema: "public", table: "votes", filter: `post_id=eq.${postId}` }, () => setCount(c => Math.max(0, c - 1)))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [postId]);

  const toggle = async (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    if (!user) { toast.info("Sign in to vote"); nav({ to: "/auth" }); return; }
    if (busy) return;
    setBusy(true);
    const wasVoted = voted;
    setVoted(!wasVoted);
    setCount(c => c + (wasVoted ? -1 : 1));
    try {
      if (wasVoted) {
        const { error } = await supabase.from("votes").delete().eq("post_id", postId).eq("user_id", user.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("votes").insert({ post_id: postId, user_id: user.id });
        if (error) throw error;
      }
    } catch (err) {
      setVoted(wasVoted);
      setCount(c => c + (wasVoted ? 1 : -1));
      toast.error("Vote failed");
      console.error(err);
    } finally {
      setBusy(false);
    }
  };

  return (
    <motion.button
      whileTap={{ scale: 0.9 }}
      onClick={toggle}
      className={cn(
        "flex items-center gap-1.5 rounded-full transition-all",
        size === "lg" ? "px-4 py-2 text-base" : "px-3 py-1.5 text-sm",
        voted
          ? "bg-primary/20 text-primary glow-primary"
          : "bg-muted hover:bg-muted/70 text-foreground",
      )}
      aria-label={voted ? "Remove vote" : "Vote"}
    >
      <Heart className={cn(size === "lg" ? "size-5" : "size-4", voted && "fill-primary")} />
      <span className="font-medium tabular-nums">{nFmt(count)}</span>
    </motion.button>
  );
}
