import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { MapPin, MessageCircle } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { VoteButton } from "@/components/VoteButton";
import { nFmt, timeAgo } from "@/lib/format";

export type PostCardData = {
  id: string;
  title: string;
  description: string | null;
  cover_url: string | null;
  location_name: string | null;
  city: string | null;
  country: string | null;
  vote_count: number;
  comment_count: number;
  created_at: string;
  tags: string[] | null;
  author: { id: string; username: string; avatar_url: string | null; display_name: string | null } | null;
  category?: { name: string; color: string | null; icon: string | null } | null;
};

export function PostCard({ post }: { post: PostCardData }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.35 }}
      className="glass rounded-3xl overflow-hidden hover-lift"
    >
      <Link to="/post/$id" params={{ id: post.id }} className="block">
        {post.cover_url ? (
          <div className="aspect-[16/10] w-full overflow-hidden bg-muted">
            <img src={post.cover_url} alt={post.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-500 hover:scale-105" />
          </div>
        ) : (
          <div className="aspect-[16/10] w-full gradient-brand grid place-items-center text-white/80">
            <MapPin className="size-10" />
          </div>
        )}
      </Link>
      <div className="p-4 space-y-3">
        <div className="flex items-center gap-2">
          {post.author && (
            <Link to="/u/$username" params={{ username: post.author.username }} className="flex items-center gap-2 min-w-0">
              <Avatar className="size-7">
                <AvatarImage src={post.author.avatar_url ?? undefined} />
                <AvatarFallback className="text-[10px] bg-primary/20 text-primary">{post.author.username.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium truncate hover:text-primary">@{post.author.username}</span>
            </Link>
          )}
          <span className="text-xs text-muted-foreground ml-auto shrink-0">{timeAgo(post.created_at)}</span>
        </div>
        <Link to="/post/$id" params={{ id: post.id }}>
          <h3 className="font-display font-bold text-lg leading-tight line-clamp-2 hover:text-primary transition-colors">{post.title}</h3>
        </Link>
        {(post.location_name || post.city) && (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <MapPin className="size-3.5" />
            <span className="truncate">{[post.location_name, post.city, post.country].filter(Boolean).join(", ")}</span>
          </div>
        )}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {post.category && (
              <Badge variant="outline" className="text-xs border-primary/40 text-primary">{post.category.icon} {post.category.name}</Badge>
            )}
            {post.tags.slice(0, 3).map(t => (
              <Badge key={t} variant="secondary" className="text-xs">#{t}</Badge>
            ))}
          </div>
        )}
        <div className="flex items-center gap-3 pt-1">
          <VoteButton postId={post.id} initialCount={post.vote_count} />
          <Link to="/post/$id" params={{ id: post.id }} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <MessageCircle className="size-4" />
            {nFmt(post.comment_count)}
          </Link>
        </div>
      </div>
    </motion.article>
  );
}
