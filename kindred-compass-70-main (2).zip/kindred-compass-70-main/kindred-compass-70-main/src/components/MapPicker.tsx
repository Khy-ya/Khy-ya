import { useEffect, useRef, useState } from "react";
import { Loader2, MapPin, Locate } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import "leaflet/dist/leaflet.css";

// Client-only Leaflet map picker. Dynamically loads leaflet to avoid SSR window access.
export function MapPicker({
  value,
  onChange,
  height = 320,
}: {
  value?: { lat: number; lng: number } | null;
  onChange: (v: { lat: number; lng: number; label?: string }) => void;
  height?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<import("leaflet").Map | null>(null);
  const markerRef = useRef<import("leaflet").Marker | null>(null);
  const [ready, setReady] = useState(false);
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    let disposed = false;
    (async () => {
      const L = (await import("leaflet")).default;
      // Fix default icon paths
      // @ts-expect-error internal
      delete L.Icon.Default.prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
        iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
        shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      });
      if (disposed || !ref.current) return;
      const start = value ?? { lat: 20, lng: 0 };
      const map = L.map(ref.current, { zoomControl: true }).setView([start.lat, start.lng], value ? 13 : 2);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://openstreetmap.org">OpenStreetMap</a>',
        maxZoom: 19,
      }).addTo(map);
      const marker = value ? L.marker([start.lat, start.lng], { draggable: true }).addTo(map) : null;
      mapRef.current = map;
      markerRef.current = marker;

      const setMarker = (lat: number, lng: number) => {
        if (markerRef.current) markerRef.current.setLatLng([lat, lng]);
        else markerRef.current = L.marker([lat, lng], { draggable: true }).addTo(map).on("dragend", (e) => {
          const p = (e.target as import("leaflet").Marker).getLatLng();
          onChange({ lat: p.lat, lng: p.lng });
        });
        markerRef.current!.on("dragend", (e) => {
          const p = (e.target as import("leaflet").Marker).getLatLng();
          onChange({ lat: p.lat, lng: p.lng });
        });
        onChange({ lat, lng });
      };

      map.on("click", (e) => {
        const { lat, lng } = e.latlng;
        setMarker(lat, lng);
      });

      setReady(true);
    })();
    return () => { disposed = true; mapRef.current?.remove(); mapRef.current = null; markerRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const detect = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition((pos) => {
      const { latitude, longitude } = pos.coords;
      mapRef.current?.setView([latitude, longitude], 14);
      onChange({ lat: latitude, lng: longitude });
      // ensure marker
      if (mapRef.current && !markerRef.current) {
        import("leaflet").then(({ default: L }) => {
          markerRef.current = L.marker([latitude, longitude], { draggable: true }).addTo(mapRef.current!);
        });
      } else {
        markerRef.current?.setLatLng([latitude, longitude]);
      }
    });
  };

  const search = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setSearching(true);
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`);
      const data = await res.json();
      if (data[0]) {
        const lat = parseFloat(data[0].lat), lng = parseFloat(data[0].lon);
        mapRef.current?.setView([lat, lng], 13);
        if (markerRef.current) markerRef.current.setLatLng([lat, lng]);
        else if (mapRef.current) {
          const L = (await import("leaflet")).default;
          markerRef.current = L.marker([lat, lng], { draggable: true }).addTo(mapRef.current);
        }
        onChange({ lat, lng, label: data[0].display_name });
      }
    } finally { setSearching(false); }
  };

  return (
    <div className="space-y-2">
      <form onSubmit={search} className="flex gap-2">
        <Input placeholder="Search a place…" value={query} onChange={e => setQuery(e.target.value)} />
        <Button type="submit" size="icon" variant="secondary" disabled={searching}>
          {searching ? <Loader2 className="size-4 animate-spin" /> : <MapPin className="size-4" />}
        </Button>
        <Button type="button" size="icon" variant="secondary" onClick={detect} title="Use my location">
          <Locate className="size-4" />
        </Button>
      </form>
      <div ref={ref} style={{ height }} className="w-full rounded-2xl overflow-hidden border border-border relative">
        {!ready && <div className="absolute inset-0 grid place-items-center bg-muted"><Loader2 className="animate-spin" /></div>}
      </div>
    </div>
  );
}
