import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  Home, Compass, Flame, Trophy, Map, Bell, Bookmark, PlusCircle,
  Settings, User, LayoutDashboard, Gift, Shield, LogOut, Search, Menu, X,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { NotificationBell } from "@/components/NotificationBell";
import { cn } from "@/lib/utils";

type NavItem = { to: string; label: string; icon: typeof Home; auth?: boolean };
const NAV: NavItem[] = [
  { to: "/home", label: "Home", icon: Home, auth: true },
  { to: "/explore", label: "Explore", icon: Compass },
  { to: "/trending", label: "Trending", icon: Flame },
  { to: "/map", label: "Map", icon: Map },
  { to: "/leaderboards", label: "Leaders", icon: Trophy },
  { to: "/bookmarks", label: "Saved", icon: Bookmark, auth: true },
  { to: "/rewards", label: "Rewards", icon: Gift, auth: true },
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, auth: true },
];

export function AppShell({ children }: { children: ReactNode }) {
  const { user, profile, isAdmin, signOut } = useAuth();
  const loc = useLocation();
  const nav = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const items = NAV.filter(n => !n.auth || user);

  const handleSignOut = async () => {
    await signOut();
    nav({ to: "/" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* top bar */}
      <header className="sticky top-0 z-40 glass border-b border-border/60">
        <div className="mx-auto max-w-7xl px-4 h-14 flex items-center gap-3">
          <button
            className="lg:hidden -ml-1"
            onClick={() => setMobileOpen(v => !v)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <div className="size-8 rounded-xl gradient-brand grid place-items-center text-white font-bold text-sm">K</div>
            <span className="font-display font-bold text-lg tracking-tight text-gradient">KHY YA</span>
          </Link>
          <div className="flex-1 max-w-md mx-auto hidden md:block">
            <button
              onClick={() => nav({ to: "/search" })}
              className="w-full flex items-center gap-2 px-3 h-9 rounded-full bg-muted/60 hover:bg-muted text-muted-foreground text-sm transition-colors"
            >
              <Search className="size-4" />
              Search locations, users, tags…
            </button>
          </div>
          <div className="ml-auto flex items-center gap-1">
            <ThemeToggle />
            {user ? (
              <>
                <NotificationBell />
                <Link to="/create">
                  <Button size="sm" className="gradient-brand text-white hover:opacity-90 gap-1.5 hidden sm:inline-flex">
                    <PlusCircle className="size-4" /> Post
                  </Button>
                </Link>
                <Link to="/u/$username" params={{ username: profile?.username ?? "" }} className="ml-1">
                  <Avatar className="size-8 border border-border">
                    <AvatarImage src={profile?.avatar_url ?? undefined} />
                    <AvatarFallback className="bg-primary/20 text-primary text-xs">
                      {(profile?.username ?? "?").slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Link>
              </>
            ) : (
              <>
                <Link to="/auth"><Button variant="ghost" size="sm">Sign in</Button></Link>
                <Link to="/auth" search={{ mode: "signup" } as never}>
                  <Button size="sm" className="gradient-brand text-white">Join</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-6 grid lg:grid-cols-[220px_1fr] gap-6">
        {/* sidebar */}
        <aside className={cn(
          "lg:block lg:sticky lg:top-20 lg:self-start",
          mobileOpen ? "block fixed inset-0 top-14 z-30 bg-background p-4 overflow-y-auto" : "hidden"
        )}>
          <nav className="flex flex-col gap-1">
            {items.map(item => {
              const active = loc.pathname === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to as never}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
                    active
                      ? "bg-primary/15 text-foreground glow-primary"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
            {user && (
              <>
                <div className="my-2 border-t border-border/60" />
                <Link to="/settings" onClick={() => setMobileOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-muted-foreground hover:bg-muted hover:text-foreground">
                  <Settings className="size-4" /> Settings
                </Link>
                {isAdmin && (
                  <Link to="/admin" onClick={() => setMobileOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-accent hover:bg-muted">
                    <Shield className="size-4" /> Admin
                  </Link>
                )}
                <button onClick={handleSignOut} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-muted-foreground hover:bg-muted hover:text-foreground text-left">
                  <LogOut className="size-4" /> Sign out
                </button>
              </>
            )}
            {profile && (
              <div className="mt-4 p-3 rounded-2xl glass">
                <div className="text-xs text-muted-foreground">Level {profile.level}</div>
                <div className="text-lg font-display font-bold text-gradient">{profile.xp} XP</div>
                <div className="flex justify-between text-xs mt-1">
                  <span>🪙 {profile.coins}</span>
                  <span>💎 {profile.gems}</span>
                  <span>🔥 {profile.streak_days}d</span>
                </div>
              </div>
            )}
          </nav>
        </aside>

        <motion.main
          key={loc.pathname}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="min-w-0"
        >
          {children}
        </motion.main>
      </div>

      {/* mobile bottom tab */}
      {user && (
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 glass border-t border-border/60">
          <div className="grid grid-cols-5 h-14">
            {[
              { to: "/home", icon: Home },
              { to: "/explore", icon: Compass },
              { to: "/create", icon: PlusCircle },
              { to: "/leaderboards", icon: Trophy },
              { to: "/u/$username", params: { username: profile?.username ?? "" }, icon: User },
            ].map((it, i) => {
              const Icon = it.icon;
              return (
                <Link key={i} to={it.to as never} params={it.params as never} className="flex items-center justify-center text-muted-foreground data-[status=active]:text-primary" activeProps={{ className: "text-primary" }}>
                  <Icon className="size-5" />
                </Link>
              );
            })}
          </div>
        </nav>
      )}

      <Footer />
    </div>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border/60 mt-16 pb-20 lg:pb-8">
      <div className="mx-auto max-w-7xl px-4 py-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <div className="size-6 rounded-lg gradient-brand grid place-items-center text-white font-bold text-xs">K</div>
          <span>© {new Date().getFullYear()} KHY YA</span>
        </div>
        <div className="flex gap-4">
          <Link to="/about" className="hover:text-foreground">About</Link>
          <Link to="/faq" className="hover:text-foreground">FAQ</Link>
          <Link to="/help" className="hover:text-foreground">Help</Link>
          <Link to="/contact" className="hover:text-foreground">Contact</Link>
          <Link to="/privacy" className="hover:text-foreground">Privacy</Link>
          <Link to="/terms" className="hover:text-foreground">Terms</Link>
        </div>
        <div>Created by <span className="text-gradient font-semibold">Abhijeet Majik</span></div>
      </div>
    </footer>
  );
}
