import { createFileRoute } from "@tanstack/react-router";
import { Wrench } from "lucide-react";
export const Route = createFileRoute("/maintenance")({
  head: () => ({ meta: [{ title: "Maintenance — KHY YA" }, { name: "robots", content: "noindex" }] }),
  component: () => (
    <div className="min-h-screen grid place-items-center bg-background text-foreground px-4">
      <div className="text-center max-w-md">
        <Wrench className="size-12 mx-auto text-accent mb-4" />
        <h1 className="font-display font-bold text-3xl">We'll be right back</h1>
        <p className="text-muted-foreground mt-2">KHY YA is undergoing a quick upgrade. Check back in a few minutes.</p>
      </div>
    </div>
  ),
});
