import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [{ title: "Contact — KHY YA" }] }),
  component: Contact,
});

const schema = z.object({
  name: z.string().trim().min(1).max(80),
  email: z.string().trim().email().max(255),
  message: z.string().trim().min(10).max(2000),
});

function Contact() {
  const [name, setName] = useState(""); const [email, setEmail] = useState(""); const [message, setMessage] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = schema.safeParse({ name, email, message });
    if (!r.success) { toast.error(r.error.errors[0].message); return; }
    // Store in localStorage; in production this would post to a server function
    const existing = JSON.parse(localStorage.getItem("khyya-contacts") || "[]");
    existing.push({ ...r.data, at: new Date().toISOString() });
    localStorage.setItem("khyya-contacts", JSON.stringify(existing));
    setName(""); setEmail(""); setMessage("");
    toast.success("Thanks — we'll get back to you.");
  };
  return (
    <AppShell>
      <div className="max-w-lg">
        <h1 className="font-display font-bold text-3xl mb-2">Contact us</h1>
        <p className="text-muted-foreground text-sm mb-6">Questions, feedback, bug reports — we read everything.</p>
        <form onSubmit={submit} className="glass rounded-3xl p-6 space-y-4">
          <div><Label htmlFor="n">Name</Label><Input id="n" value={name} onChange={e => setName(e.target.value)} required maxLength={80} /></div>
          <div><Label htmlFor="e">Email</Label><Input id="e" type="email" value={email} onChange={e => setEmail(e.target.value)} required maxLength={255} /></div>
          <div><Label htmlFor="m">Message</Label><Textarea id="m" value={message} onChange={e => setMessage(e.target.value)} required minLength={10} maxLength={2000} rows={5} /></div>
          <Button type="submit" className="gradient-brand text-white w-full">Send message</Button>
        </form>
      </div>
    </AppShell>
  );
}
