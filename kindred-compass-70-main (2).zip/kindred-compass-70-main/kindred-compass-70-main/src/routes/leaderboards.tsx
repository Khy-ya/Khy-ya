import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Crown, Medal } from "lucide-react";
import { nFmt } from "@/lib/format";

export const Route = createFileRoute("/leaderboards")({
  head: () => ({ meta: [{ title: "Leaderboards — KHY YA" }, { name: "description", content: "Daily, weekly, monthly, and global leaderboards of the top locations." }] }),
  component: Leaderboards,
});

type Row = { post_id: string; title: string; cover_url: string | null; username: string; avatar_url: string | null; votes: number };
const VIEWS = { daily: "leaderboard_daily", weekly: "leaderboard_weekly", monthly: "leaderboard_monthly", global: "leaderboard_global" } as const;
type Period = keyof typeof VIEWS;

function Leaderboards() {
  const [period, setPeriod] = useState<Period>("daily");
  const { data, isLoading } = useQuery({
    queryKey: ["lb", period],
    queryFn: async () => (await supabase.from(VIEWS[period]).select("*").limit(50)).data as Row[] ?? [],
  });
  return (
    <AppShell>
      <div className="mb-6 flex items-center gap-3">
        <Trophy className="size-8 text-warning" />
        <div><h1 className="font-display font-bold text-3xl">Leaderboards</h1><p className="text-muted-foreground text-sm">Top locations by community votes</p></div>
      </div>
      <Tabs value={period} onValueChange={v => setPeriod(v as Period)}>
        <TabsList className="mb-6">
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
          <TabsTrigger value="global">All time</TabsTrigger>
        </TabsList>
      </Tabs>
      {isLoading ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-2xl" />)}</div>
      ) : data?.length ? (
        <div className="space-y-2">
          {data.map((r, i) => {
            const rankIcon = i === 0 ? <Crown className="size-6 text-warning" /> : i === 1 ? <Medal className="size-6 text-muted-foreground" /> : i === 2 ? <Medal className="size-6 text-orange-500" /> : <span className="w-6 text-center text-muted-foreground font-mono">{i + 1}</span>;
            return (
              <Link key={r.post_id} to="/post/$id" params={{ id: r.post_id }} className="glass rounded-2xl p-3 flex items-center gap-4 hover-lift">
                <div className="w-8 grid place-items-center">{rankIcon}</div>
                {r.cover_url && <img src={r.cover_url} alt="" className="size-14 rounded-xl object-cover" />}
                <div className="flex-1 min-w-0"><div className="font-medium truncate">{r.title}</div><div className="text-xs text-muted-foreground">@{r.username}</div></div>
                <div className="text-right"><div className="font-display font-bold text-lg text-gradient">{nFmt(r.votes)}</div><div className="text-xs text-muted-foreground">votes</div></div>
              </Link>
            );
          })}
        </div>
      ) : (
        <div className="glass rounded-3xl p-10 text-center text-muted-foreground">No votes in this period yet.</div>
      )}
    </AppShell>
  );
}
