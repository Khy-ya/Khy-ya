import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [{ title: "Privacy Policy — KHY YA" }] }),
  component: () => (
    <AppShell>
      <div className="max-w-2xl space-y-4 text-sm text-muted-foreground">
        <h1 className="font-display font-bold text-3xl text-foreground">Privacy Policy</h1>
        <p>KHY YA respects your privacy. This page describes what we collect and why.</p>
        <h2 className="text-foreground font-display font-bold text-lg mt-6">Data we collect</h2>
        <p>Account (email, username), profile info you provide, content you post (locations, screenshots, comments), and basic usage analytics required to operate the service.</p>
        <h2 className="text-foreground font-display font-bold text-lg mt-6">How we use it</h2>
        <p>To power your account, show your posts, calculate leaderboards, award XP/coins, notify you of activity, and moderate content.</p>
        <h2 className="text-foreground font-display font-bold text-lg mt-6">Data sharing</h2>
        <p>We do not sell your data. Content you make public is visible to everyone. Delete your account any time from Settings.</p>
        <h2 className="text-foreground font-display font-bold text-lg mt-6">Cookies</h2>
        <p>Session cookies are used for authentication. No tracking cookies.</p>
      </div>
    </AppShell>
  ),
});
