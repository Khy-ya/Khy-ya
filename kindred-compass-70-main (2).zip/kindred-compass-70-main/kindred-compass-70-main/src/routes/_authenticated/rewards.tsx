import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Gift, Coins, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/rewards")({
  head: () => ({ meta: [{ title: "Rewards — KHY YA" }] }),
  component: RewardsPage,
});

function RewardsPage() {
  const { user, refresh } = useAuth();
  const [spinning, setSpinning] = useState(false);
  const [prize, setPrize] = useState<string | null>(null);

  const { data: today, refetch } = useQuery({
    queryKey: ["daily", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const t = new Date().toISOString().slice(0, 10);
      const { data } = await supabase.from("daily_rewards").select("claimed_date").eq("user_id", user!.id).eq("claimed_date", t).maybeSingle();
      return !!data;
    },
  });

  const claim = async () => {
    if (!user) return;
    const t = new Date().toISOString().slice(0, 10);
    const coins = 10 + Math.floor(Math.random() * 20);
    const xp = 20 + Math.floor(Math.random() * 30);
    const { error } = await supabase.from("daily_rewards").insert({ user_id: user.id, claimed_date: t, coins, xp });
    if (error) { toast.error("Already claimed today"); return; }
    const cur = (await supabase.from("profiles").select("coins,xp").eq("id", user.id).single()).data!;
    await supabase.from("profiles").update({ coins: cur.coins + coins, xp: cur.xp + xp }).eq("id", user.id);
    toast.success(`+${coins} coins · +${xp} XP`);
    refetch(); refresh();
  };

  const spin = async () => {
    if (!user) return;
    setSpinning(true); setPrize(null);
    setTimeout(async () => {
      const prizes = ["+50 XP", "+100 coins", "+5 gems", "+200 XP", "+25 coins", "+1 gem"];
      const p = prizes[Math.floor(Math.random() * prizes.length)];
      setPrize(p); setSpinning(false);
      const cur = (await supabase.from("profiles").select("xp,coins,gems").eq("id", user.id).single()).data!;
      const updates: { xp?: number; coins?: number; gems?: number } = {};
      if (p.includes("XP")) updates.xp = cur.xp + parseInt(p.match(/\d+/)![0]);
      if (p.includes("coin")) updates.coins = cur.coins + parseInt(p.match(/\d+/)![0]);
      if (p.includes("gem")) updates.gems = cur.gems + parseInt(p.match(/\d+/)![0]);
      await supabase.from("profiles").update(updates).eq("id", user.id);
      refresh();
    }, 1800);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <h1 className="font-display font-bold text-3xl">Rewards</h1>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="glass rounded-3xl p-6">
          <Gift className="size-8 text-primary mb-3" />
          <h2 className="font-display font-bold text-xl">Daily reward</h2>
          <p className="text-sm text-muted-foreground mt-1">Claim once every 24h.</p>
          <Button onClick={claim} disabled={today} className="gradient-brand text-white mt-4 w-full">
            {today ? "Claimed today" : "Claim now"}
          </Button>
        </div>
        <div className="glass rounded-3xl p-6">
          <Sparkles className="size-8 text-accent mb-3" />
          <h2 className="font-display font-bold text-xl">Lucky wheel</h2>
          <p className="text-sm text-muted-foreground mt-1">Random reward. One free spin.</p>
          <motion.div animate={{ rotate: spinning ? 720 : 0 }} transition={{ duration: 1.6 }} className="my-4 mx-auto size-24 rounded-full gradient-brand grid place-items-center text-white text-xl font-bold">
            ?
          </motion.div>
          {prize && <p className="text-center text-lg font-display font-bold text-gradient mb-2">{prize}</p>}
          <Button onClick={spin} disabled={spinning} variant="outline" className="w-full">Spin</Button>
        </div>
      </div>

      <div className="glass rounded-3xl p-6">
        <h2 className="font-display font-bold text-xl flex items-center gap-2"><Coins className="size-5 text-warning" /> Coin store</h2>
        <p className="text-sm text-muted-foreground mt-1 mb-4">Redeem coins for perks (coming soon).</p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { name: "Profile flair", price: 500 },
            { name: "Cover animation", price: 1500 },
            { name: "Rare badge", price: 3000 },
          ].map(i => (
            <div key={i.name} className="rounded-2xl bg-muted p-4">
              <div className="font-medium">{i.name}</div>
              <div className="text-sm text-muted-foreground mt-1">🪙 {i.price}</div>
              <Button size="sm" variant="outline" className="mt-3 w-full" disabled>Soon</Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
