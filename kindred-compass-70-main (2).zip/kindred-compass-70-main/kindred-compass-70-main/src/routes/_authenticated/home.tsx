import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PostCard, type PostCardData } from "@/components/PostCard";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/home")({
  head: () => ({ meta: [{ title: "Home — KHY YA" }] }),
  component: HomePage,
});

async function fetchFeed(): Promise<PostCardData[]> {
  const { data, error } = await supabase
    .from("posts")
    .select("id,title,description,cover_url,location_name,city,country,vote_count,comment_count,created_at,tags,author:profiles!posts_author_profile_fkey(id,username,avatar_url,display_name),category:categories(name,color,icon)")
    .eq("status", "published")
    .order("created_at", { ascending: false })
    .limit(30);
  if (error) throw error;
  return (data as unknown as PostCardData[]) ?? [];
}

function HomePage() {
  const { data, isLoading } = useQuery({ queryKey: ["feed"], queryFn: fetchFeed });
  return (
    <div>
      <div className="mb-6">
        <h1 className="font-display font-bold text-3xl">Your feed</h1>
        <p className="text-muted-foreground text-sm mt-1">Fresh locations from the community</p>
      </div>
      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-80 rounded-3xl" />)}
        </div>
      ) : data && data.length ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {data.map(p => <PostCard key={p.id} post={p} />)}
        </div>
      ) : (
        <div className="glass rounded-3xl p-10 text-center">
          <p className="text-muted-foreground">No posts yet. Be the first to share!</p>
        </div>
      )}
    </div>
  );
}
