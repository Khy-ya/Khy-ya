import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Shield, Users, FileText, Flag, Megaphone, Trash2 } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — KHY YA" }, { name: "robots", content: "noindex" }] }),
  component: AdminPage,
});

function AdminPage() {
  const { isAdmin, loading } = useAuth();
  if (loading) return <p>Loading…</p>;
  if (!isAdmin) return (
    <div className="glass rounded-3xl p-10 text-center">
      <Shield className="size-10 mx-auto text-muted-foreground mb-3" />
      <h1 className="font-display font-bold text-2xl">Admin only</h1>
      <p className="text-muted-foreground mt-2">You don't have access to this area.</p>
    </div>
  );
  return (
    <div>
      <h1 className="font-display font-bold text-3xl mb-6">Admin panel</h1>
      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users"><Users className="size-4 mr-1" /> Users</TabsTrigger>
          <TabsTrigger value="posts"><FileText className="size-4 mr-1" /> Posts</TabsTrigger>
          <TabsTrigger value="reports"><Flag className="size-4 mr-1" /> Reports</TabsTrigger>
          <TabsTrigger value="ann"><Megaphone className="size-4 mr-1" /> Announcements</TabsTrigger>
        </TabsList>
        <TabsContent value="users" className="mt-6"><AdminUsers /></TabsContent>
        <TabsContent value="posts" className="mt-6"><AdminPosts /></TabsContent>
        <TabsContent value="reports" className="mt-6"><AdminReports /></TabsContent>
        <TabsContent value="ann" className="mt-6"><AdminAnnouncements /></TabsContent>
      </Tabs>
    </div>
  );
}

function AdminUsers() {
  const { data, refetch } = useQuery({
    queryKey: ["admin-users"],
    queryFn: async () => (await supabase.from("profiles").select("id,username,display_name,xp,level,verified,banned").order("created_at", { ascending: false }).limit(100)).data ?? [],
  });
  const toggleBan = async (id: string, banned: boolean) => {
    await supabase.from("profiles").update({ banned: !banned }).eq("id", id);
    toast.success(!banned ? "Banned" : "Unbanned"); refetch();
  };
  const toggleVerify = async (id: string, v: boolean) => {
    await supabase.from("profiles").update({ verified: !v }).eq("id", id);
    refetch();
  };
  return (
    <div className="glass rounded-3xl overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-muted text-left"><tr><th className="p-3">User</th><th className="p-3">XP</th><th className="p-3">Status</th><th className="p-3">Actions</th></tr></thead>
        <tbody>
          {(data ?? []).map(u => (
            <tr key={u.id} className="border-t border-border">
              <td className="p-3">@{u.username} {u.verified && "✓"}</td>
              <td className="p-3">{u.xp}</td>
              <td className="p-3">{u.banned ? <span className="text-destructive">Banned</span> : "Active"}</td>
              <td className="p-3 flex gap-2">
                <Button size="sm" variant="outline" onClick={() => toggleVerify(u.id, u.verified)}>{u.verified ? "Unverify" : "Verify"}</Button>
                <Button size="sm" variant={u.banned ? "outline" : "destructive"} onClick={() => toggleBan(u.id, u.banned)}>{u.banned ? "Unban" : "Ban"}</Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AdminPosts() {
  const { data, refetch } = useQuery({
    queryKey: ["admin-posts"],
    queryFn: async () => (await supabase.from("posts").select("id,title,vote_count,status,author:profiles!posts_author_profile_fkey(username)").order("created_at", { ascending: false }).limit(100)).data as unknown as { id: string; title: string; vote_count: number; status: string; author: { username: string } | null }[] ?? [],
  });
  const remove = async (id: string) => { if (!confirm("Delete post?")) return; await supabase.from("posts").delete().eq("id", id); refetch(); };
  return (
    <div className="glass rounded-3xl overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-muted text-left"><tr><th className="p-3">Title</th><th className="p-3">Author</th><th className="p-3">Votes</th><th className="p-3">Status</th><th className="p-3"></th></tr></thead>
        <tbody>
          {(data ?? []).map((p) => (
            <tr key={p.id} className="border-t border-border">
              <td className="p-3 truncate max-w-xs">{p.title}</td>
              <td className="p-3">@{p.author?.username}</td>
              <td className="p-3">{p.vote_count}</td>
              <td className="p-3">{p.status}</td>
              <td className="p-3"><Button size="sm" variant="destructive" onClick={() => remove(p.id)}><Trash2 className="size-4" /></Button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AdminReports() {
  const { data, refetch } = useQuery({
    queryKey: ["admin-reports"],
    queryFn: async () => (await supabase.from("reports").select("id,reason,details,status,created_at,post_id").order("created_at", { ascending: false }).limit(100)).data ?? [],
  });
  const resolve = async (id: string, status: "resolved" | "rejected") => { await supabase.from("reports").update({ status }).eq("id", id); refetch(); };
  return (
    <div className="space-y-2">
      {(data ?? []).map(r => (
        <div key={r.id} className="glass rounded-2xl p-4 flex items-center justify-between">
          <div>
            <div className="font-medium">{r.reason}</div>
            <div className="text-xs text-muted-foreground">{r.details}</div>
            <div className="text-xs">Status: <b>{r.status}</b></div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => resolve(r.id, "resolved")}>Resolve</Button>
            <Button size="sm" variant="ghost" onClick={() => resolve(r.id, "rejected")}>Reject</Button>
          </div>
        </div>
      ))}
      {data && !data.length && <p className="text-muted-foreground text-sm">No reports.</p>}
    </div>
  );
}

function AdminAnnouncements() {
  const [title, setTitle] = useState(""); const [body, setBody] = useState("");
  const { user } = useAuth();
  const { data, refetch } = useQuery({
    queryKey: ["ann"],
    queryFn: async () => (await supabase.from("announcements").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  const post = async () => {
    if (!title || !body || !user) return;
    await supabase.from("announcements").insert({ title, body, created_by: user.id });
    setTitle(""); setBody(""); toast.success("Announcement posted"); refetch();
  };
  return (
    <div className="space-y-4">
      <div className="glass rounded-3xl p-6 space-y-3">
        <Input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
        <Textarea placeholder="Body" value={body} onChange={e => setBody(e.target.value)} rows={3} />
        <Button onClick={post} className="gradient-brand text-white">Post announcement</Button>
      </div>
      {(data ?? []).map(a => (
        <div key={a.id} className="glass rounded-2xl p-4">
          <div className="font-medium">{a.title}</div>
          <div className="text-sm text-muted-foreground">{a.body}</div>
        </div>
      ))}
    </div>
  );
}
