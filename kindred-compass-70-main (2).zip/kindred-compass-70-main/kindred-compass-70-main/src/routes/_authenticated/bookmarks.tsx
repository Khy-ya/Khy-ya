import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { PostCard, type PostCardData } from "@/components/PostCard";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/bookmarks")({
  head: () => ({ meta: [{ title: "Saved — KHY YA" }] }),
  component: BookmarksPage,
});

function BookmarksPage() {
  const { user } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["bookmarks", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("bookmarks")
        .select("post:posts(id,title,description,cover_url,location_name,city,country,vote_count,comment_count,created_at,tags,author:profiles!posts_author_profile_fkey(id,username,avatar_url,display_name),category:categories(name,color,icon))")
        .eq("user_id", user!.id).order("created_at", { ascending: false });
      return ((data ?? []) as unknown as { post: PostCardData }[]).map(x => x.post).filter(Boolean);
    },
  });
  return (
    <div>
      <h1 className="font-display font-bold text-3xl mb-6">Saved locations</h1>
      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-80 rounded-3xl" />)}</div>
      ) : data && data.length ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{data.map(p => <PostCard key={p.id} post={p} />)}</div>
      ) : (
        <div className="glass rounded-3xl p-10 text-center text-muted-foreground">No bookmarks yet. Tap the bookmark icon on any post.</div>
      )}
    </div>
  );
}
