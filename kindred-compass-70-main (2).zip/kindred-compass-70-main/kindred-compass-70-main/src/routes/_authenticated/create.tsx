import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { toast } from "sonner";
import { Loader2, Upload, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { uploadImage } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPicker } from "@/components/MapPicker";

export const Route = createFileRoute("/_authenticated/create")({
  head: () => ({ meta: [{ title: "Post a location — KHY YA" }] }),
  component: CreatePage,
});

const schema = z.object({
  title: z.string().trim().min(3, "Title 3–140 chars").max(140),
  description: z.string().max(3000).optional(),
  category_id: z.string().uuid().nullable(),
  tags: z.array(z.string()).max(8),
});

function CreatePage() {
  const nav = useNavigate();
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<string | null>(null);
  const [tagsInput, setTagsInput] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [loc, setLoc] = useState<{ lat: number; lng: number; label?: string } | null>(null);
  const [locationName, setLocationName] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: cats } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => (await supabase.from("categories").select("id,name,icon").order("sort_order")).data ?? [],
  });

  const onFiles = (list: FileList | null) => {
    if (!list) return;
    const arr = Array.from(list).slice(0, 5);
    setFiles(arr);
    setPreviews(arr.map(f => URL.createObjectURL(f)));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const tags = tagsInput.split(",").map(t => t.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "")).filter(Boolean).slice(0, 8);
    const parsed = schema.safeParse({ title, description, category_id: category, tags });
    if (!parsed.success) { toast.error(parsed.error.errors[0].message); return; }
    if (files.length === 0) { toast.error("Add at least one screenshot"); return; }
    setBusy(true);
    try {
      const uploaded = await Promise.all(files.map(f => uploadImage("post-images", user.id, f)));
      const cover = uploaded[0].url;
      const label = loc?.label || locationName;
      const city = label ? label.split(",").slice(-3, -2)[0]?.trim() : null;
      const country = label ? label.split(",").slice(-1)[0]?.trim() : null;
      const { data: post, error } = await supabase.from("posts").insert({
        author_id: user.id, title, description: description || null,
        category_id: category, tags,
        latitude: loc?.lat ?? null, longitude: loc?.lng ?? null,
        location_name: label || null, city, country,
        cover_url: cover, status: "published",
      }).select("id").single();
      if (error) throw error;
      await supabase.from("post_images").insert(uploaded.map((u, i) => ({ post_id: post.id, url: u.url, sort_order: i })));
      toast.success("Location posted!");
      nav({ to: "/post/$id", params: { id: post.id } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Post failed");
    } finally { setBusy(false); }
  };

  return (
    <form onSubmit={submit} className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl">Post a location</h1>
        <p className="text-muted-foreground text-sm mt-1">Screenshot proof + a map pin. That's it.</p>
      </div>

      <div className="glass rounded-3xl p-6 space-y-4">
        <div>
          <Label>Screenshots (up to 5)</Label>
          <label htmlFor="files" className="mt-2 flex items-center justify-center h-32 border-2 border-dashed border-border rounded-2xl cursor-pointer hover:bg-muted/40">
            <div className="text-center">
              <Upload className="size-6 mx-auto text-muted-foreground" />
              <p className="text-sm text-muted-foreground mt-2">Click to upload</p>
            </div>
            <input id="files" type="file" accept="image/*" multiple className="hidden" onChange={e => onFiles(e.target.files)} />
          </label>
          {previews.length > 0 && (
            <div className="mt-3 flex gap-2 flex-wrap">
              {previews.map((p, i) => (
                <div key={i} className="relative size-20 rounded-xl overflow-hidden">
                  <img src={p} className="w-full h-full object-cover" alt="" />
                  <button type="button" onClick={() => { setFiles(f => f.filter((_, j) => j !== i)); setPreviews(pr => pr.filter((_, j) => j !== i)); }} className="absolute top-0.5 right-0.5 bg-black/60 rounded-full p-0.5">
                    <X className="size-3 text-white" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <Label htmlFor="t">Title</Label>
          <Input id="t" value={title} onChange={e => setTitle(e.target.value)} maxLength={140} placeholder="Sunrise from Batur crater" required />
        </div>

        <div>
          <Label htmlFor="d">Description</Label>
          <Textarea id="d" value={description} onChange={e => setDescription(e.target.value)} maxLength={3000} placeholder="What makes this place special?" rows={4} />
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label>Category</Label>
            <Select value={category ?? undefined} onValueChange={setCategory}>
              <SelectTrigger><SelectValue placeholder="Pick one" /></SelectTrigger>
              <SelectContent>
                {(cats ?? []).map(c => <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input id="tags" value={tagsInput} onChange={e => setTagsInput(e.target.value)} placeholder="sunrise, hidden, hike" />
          </div>
        </div>

        <div>
          <Label htmlFor="ln">Location name</Label>
          <Input id="ln" value={locationName} onChange={e => setLocationName(e.target.value)} placeholder="Auto-fills from map search" />
        </div>

        <div>
          <Label>Pin on the map</Label>
          <div className="mt-2">
            <MapPicker value={loc} onChange={(v) => { setLoc(v); if (v.label) setLocationName(v.label); }} />
          </div>
          {loc && <p className="text-xs text-muted-foreground mt-2">📍 {loc.lat.toFixed(5)}, {loc.lng.toFixed(5)}</p>}
        </div>
      </div>

      <div className="flex gap-3 justify-end">
        <Button type="button" variant="outline" onClick={() => nav({ to: "/home" })}>Cancel</Button>
        <Button type="submit" className="gradient-brand text-white" disabled={busy}>
          {busy && <Loader2 className="size-4 animate-spin mr-2" />} Post location
        </Button>
      </div>
    </form>
  );
}
