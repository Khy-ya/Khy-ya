import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { uploadImage } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings — KHY YA" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user, profile, refresh } = useAuth();
  const [displayName, setDisplayName] = useState(profile?.display_name ?? "");
  const [username, setUsername] = useState(profile?.username ?? "");
  const [bio, setBio] = useState(profile?.bio ?? "");
  const [busy, setBusy] = useState(false);
  const [pwd, setPwd] = useState("");

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    const uname = username.trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
    if (uname.length < 3) { toast.error("Username too short"); setBusy(false); return; }
    const { error } = await supabase.from("profiles").update({
      username: uname, display_name: displayName || null, bio: bio || null, updated_at: new Date().toISOString(),
    }).eq("id", user.id);
    setBusy(false);
    if (error) toast.error(error.message);
    else { toast.success("Saved"); refresh(); }
  };

  const uploadAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!user || !e.target.files?.[0]) return;
    setBusy(true);
    try {
      const { url } = await uploadImage("avatars", user.id, e.target.files[0]);
      await supabase.from("profiles").update({ avatar_url: url }).eq("id", user.id);
      toast.success("Avatar updated");
      refresh();
    } catch (err) { toast.error(err instanceof Error ? err.message : "Upload failed"); }
    finally { setBusy(false); }
  };

  const changePassword = async () => {
    if (pwd.length < 8) { toast.error("Password must be 8+ chars"); return; }
    const { error } = await supabase.auth.updateUser({ password: pwd });
    if (error) toast.error(error.message); else { toast.success("Password updated"); setPwd(""); }
  };

  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="font-display font-bold text-3xl">Settings</h1>

      <form onSubmit={save} className="glass rounded-3xl p-6 space-y-4">
        <div className="flex items-center gap-4">
          <Avatar className="size-20">
            <AvatarImage src={profile?.avatar_url ?? undefined} />
            <AvatarFallback className="bg-primary/20 text-primary">{profile?.username?.slice(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <label>
            <input type="file" accept="image/*" className="hidden" onChange={uploadAvatar} />
            <Button type="button" variant="outline" asChild><span>Change avatar</span></Button>
          </label>
        </div>
        <div>
          <Label htmlFor="dn">Display name</Label>
          <Input id="dn" value={displayName} onChange={e => setDisplayName(e.target.value)} maxLength={60} />
        </div>
        <div>
          <Label htmlFor="un">Username</Label>
          <Input id="un" value={username} onChange={e => setUsername(e.target.value)} minLength={3} maxLength={30} />
        </div>
        <div>
          <Label htmlFor="bio">Bio</Label>
          <Textarea id="bio" value={bio} onChange={e => setBio(e.target.value)} maxLength={280} rows={3} />
        </div>
        <Button type="submit" className="gradient-brand text-white" disabled={busy}>
          {busy && <Loader2 className="size-4 animate-spin mr-2" />} Save changes
        </Button>
      </form>

      <div className="glass rounded-3xl p-6 space-y-3">
        <h2 className="font-display font-bold text-lg">Change password</h2>
        <Input type="password" placeholder="New password (8+ chars)" value={pwd} onChange={e => setPwd(e.target.value)} />
        <Button onClick={changePassword} variant="outline">Update password</Button>
      </div>

      <div className="glass rounded-3xl p-6 space-y-2">
        <h2 className="font-display font-bold text-lg">Account</h2>
        <p className="text-sm text-muted-foreground">Email: {user?.email}</p>
        <p className="text-sm text-muted-foreground">User ID: <code className="text-xs">{user?.id}</code></p>
      </div>
    </div>
  );
}
