import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { levelFromXp, nFmt } from "@/lib/format";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — KHY YA" }] }),
  component: DashboardPage,
});

function DashboardPage() {
  const { user, profile } = useAuth();
  const { data } = useQuery({
    queryKey: ["dashboard", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const [posts, votesCast, followers, achievements, recent] = await Promise.all([
        supabase.from("posts").select("id,vote_count,comment_count", { count: "exact" }).eq("author_id", user!.id),
        supabase.from("votes").select("*", { count: "exact", head: true }).eq("user_id", user!.id),
        supabase.from("follows").select("*", { count: "exact", head: true }).eq("following_id", user!.id),
        supabase.from("user_achievements").select("achievement:achievements(name,icon,description)").eq("user_id", user!.id),
        supabase.from("posts").select("id,title,vote_count,created_at").eq("author_id", user!.id).order("created_at", { ascending: false }).limit(5),
      ]);
      const totalVotes = (posts.data ?? []).reduce((s, p) => s + (p.vote_count ?? 0), 0);
      return {
        postCount: posts.count ?? 0,
        totalVotes,
        votesCast: votesCast.count ?? 0,
        followers: followers.count ?? 0,
        achievements: (achievements.data ?? []) as { achievement: { name: string; icon: string; description: string } }[],
        recent: recent.data ?? [],
      };
    },
  });

  const lvl = levelFromXp(profile?.xp ?? 0);
  return (
    <div className="space-y-6">
      <h1 className="font-display font-bold text-3xl">Dashboard</h1>

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: "Level", value: lvl.level },
          { label: "XP", value: nFmt(profile?.xp ?? 0) },
          { label: "Coins", value: nFmt(profile?.coins ?? 0) },
          { label: "Streak", value: `${profile?.streak_days ?? 0}d` },
        ].map(s => (
          <div key={s.label} className="glass rounded-2xl p-5">
            <div className="text-xs text-muted-foreground">{s.label}</div>
            <div className="text-3xl font-display font-bold text-gradient mt-1">{s.value}</div>
          </div>
        ))}
      </div>

      <div className="glass rounded-3xl p-6">
        <div className="flex items-center justify-between mb-2">
          <div className="text-sm font-medium">Level {lvl.level}</div>
          <div className="text-xs text-muted-foreground">{lvl.progress} / {lvl.next} XP</div>
        </div>
        <Progress value={(lvl.progress / lvl.next) * 100} />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="glass rounded-3xl p-6">
          <h2 className="font-display font-bold text-lg mb-4">Activity</h2>
          <ul className="space-y-2 text-sm">
            <li className="flex justify-between"><span className="text-muted-foreground">Posts</span><b>{data?.postCount ?? 0}</b></li>
            <li className="flex justify-between"><span className="text-muted-foreground">Total votes received</span><b>{data?.totalVotes ?? 0}</b></li>
            <li className="flex justify-between"><span className="text-muted-foreground">Votes cast</span><b>{data?.votesCast ?? 0}</b></li>
            <li className="flex justify-between"><span className="text-muted-foreground">Followers</span><b>{data?.followers ?? 0}</b></li>
          </ul>
        </div>
        <div className="glass rounded-3xl p-6">
          <h2 className="font-display font-bold text-lg mb-4">Recent posts</h2>
          {data?.recent.length ? (
            <ul className="space-y-2 text-sm">
              {data.recent.map(p => (
                <li key={p.id} className="flex justify-between gap-2">
                  <Link to="/post/$id" params={{ id: p.id }} className="hover:text-primary truncate">{p.title}</Link>
                  <span className="text-muted-foreground shrink-0">🔥 {p.vote_count}</span>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-muted-foreground">No posts yet.</p>}
        </div>
      </div>

      <div className="glass rounded-3xl p-6">
        <h2 className="font-display font-bold text-lg mb-4">Achievements ({data?.achievements.length ?? 0})</h2>
        {data?.achievements.length ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {data.achievements.map((a, i) => (
              <div key={i} className="rounded-2xl p-4 bg-muted text-center">
                <div className="text-3xl mb-2">{a.achievement.icon}</div>
                <div className="font-medium text-sm">{a.achievement.name}</div>
                <div className="text-xs text-muted-foreground">{a.achievement.description}</div>
              </div>
            ))}
          </div>
        ) : <p className="text-sm text-muted-foreground">Post, vote and comment to earn your first badge.</p>}
      </div>
    </div>
  );
}
