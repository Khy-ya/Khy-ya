import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { timeAgo } from "@/lib/format";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { CheckCheck } from "lucide-react";

type Notif = {
  id: string; type: string; message: string | null; read: boolean;
  created_at: string; post_id: string | null;
  actor: { username: string; avatar_url: string | null } | null;
};

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({ meta: [{ title: "Notifications — KHY YA" }] }),
  component: NotificationsPage,
});

function NotificationsPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<Notif[] | null>(null);

  const load = async () => {
    if (!user) return;
    const { data } = await supabase.from("notifications")
      .select("id,type,message,read,created_at,post_id,actor:profiles!notifications_actor_profile_fkey(username,avatar_url)")
      .eq("user_id", user.id).order("created_at", { ascending: false }).limit(100);
    setItems((data as unknown as Notif[]) ?? []);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [user]);

  const markAll = async () => {
    if (!user) return;
    await supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
    load();
  };

  return (
    <div className="max-w-2xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display font-bold text-3xl">Notifications</h1>
        <Button variant="outline" size="sm" onClick={markAll}><CheckCheck className="size-4 mr-1" /> Mark all read</Button>
      </div>
      {items === null ? (
        <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-2xl" />)}</div>
      ) : items.length === 0 ? (
        <div className="glass rounded-3xl p-10 text-center text-muted-foreground">All caught up ✨</div>
      ) : (
        <div className="space-y-2">
          {items.map(n => (
            <Link key={n.id} to={n.post_id ? "/post/$id" : "/notifications"} params={{ id: n.post_id ?? "" } as never} className={`block glass rounded-2xl p-4 flex items-center gap-3 hover-lift ${!n.read ? "border-primary/40" : ""}`}>
              <div className="size-10 rounded-full gradient-brand grid place-items-center text-white text-sm font-bold">{n.actor?.username?.[0]?.toUpperCase() ?? "•"}</div>
              <div className="flex-1 min-w-0">
                <p className="text-sm"><b>@{n.actor?.username ?? "someone"}</b> {n.message}</p>
                <p className="text-xs text-muted-foreground">{timeAgo(n.created_at)}</p>
              </div>
              {!n.read && <span className="size-2 rounded-full bg-primary" />}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
