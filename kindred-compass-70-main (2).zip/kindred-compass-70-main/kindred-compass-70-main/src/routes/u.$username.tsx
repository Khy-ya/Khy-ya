import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { AppShell } from "@/components/AppShell";
import { PostCard, type PostCardData } from "@/components/PostCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { nFmt, levelFromXp } from "@/lib/format";
import { UserPlus, UserCheck, Share2 } from "lucide-react";

export const Route = createFileRoute("/u/$username")({
  head: () => ({ meta: [{ title: "Profile — KHY YA" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { username } = Route.useParams();
  const { user } = useAuth();
  const [following, setFollowing] = useState(false);

  const { data: profile, isLoading } = useQuery({
    queryKey: ["profile", username],
    queryFn: async () => (await supabase.from("profiles").select("id,username,display_name,bio,avatar_url,cover_url,xp,coins,level,verified").eq("username", username).maybeSingle()).data,
  });

  const { data: posts } = useQuery({
    queryKey: ["profile-posts", profile?.id],
    enabled: !!profile,
    queryFn: async () => (await supabase.from("posts").select("id,title,description,cover_url,location_name,city,country,vote_count,comment_count,created_at,tags,author:profiles!posts_author_profile_fkey(id,username,avatar_url,display_name),category:categories(name,color,icon)").eq("author_id", profile!.id).eq("status", "published").order("created_at", { ascending: false }).limit(24)).data as unknown as PostCardData[] ?? [],
  });

  const { data: counts } = useQuery({
    queryKey: ["profile-counts", profile?.id],
    enabled: !!profile,
    queryFn: async () => {
      const [f1, f2] = await Promise.all([
        supabase.from("follows").select("*", { count: "exact", head: true }).eq("following_id", profile!.id),
        supabase.from("follows").select("*", { count: "exact", head: true }).eq("follower_id", profile!.id),
      ]);
      return { followers: f1.count ?? 0, following: f2.count ?? 0 };
    },
  });

  useEffect(() => {
    if (!user || !profile) return;
    supabase.from("follows").select("*").eq("follower_id", user.id).eq("following_id", profile.id).maybeSingle().then(({ data }) => setFollowing(!!data));
  }, [user, profile]);

  const toggleFollow = async () => {
    if (!user || !profile) return;
    if (following) {
      await supabase.from("follows").delete().eq("follower_id", user.id).eq("following_id", profile.id);
      setFollowing(false);
    } else {
      await supabase.from("follows").insert({ follower_id: user.id, following_id: profile.id });
      setFollowing(true);
    }
  };

  const share = async () => { await navigator.clipboard.writeText(window.location.href); toast.success("Profile link copied"); };

  const lvl = profile ? levelFromXp(profile.xp) : null;

  return (
    <AppShell>
      {isLoading ? (
        <div className="space-y-4"><Skeleton className="h-40 rounded-3xl" /><Skeleton className="h-24 rounded-3xl" /></div>
      ) : !profile ? (
        <div className="glass rounded-3xl p-10 text-center">User not found.</div>
      ) : (
        <div className="space-y-6">
          <div className="glass rounded-3xl overflow-hidden">
            <div className="h-40 gradient-brand relative">
              {profile.cover_url && <img src={profile.cover_url} className="w-full h-full object-cover" alt="" />}
            </div>
            <div className="p-6 -mt-12 relative">
              <div className="flex items-end justify-between flex-wrap gap-4">
                <Avatar className="size-24 border-4 border-background"><AvatarImage src={profile.avatar_url ?? undefined} /><AvatarFallback className="text-2xl bg-primary/20 text-primary">{profile.username.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex gap-2">
                  {user && user.id !== profile.id && (
                    <Button onClick={toggleFollow} className={following ? "" : "gradient-brand text-white"} variant={following ? "outline" : "default"}>
                      {following ? <><UserCheck className="size-4 mr-1" /> Following</> : <><UserPlus className="size-4 mr-1" /> Follow</>}
                    </Button>
                  )}
                  <Button variant="outline" onClick={share}><Share2 className="size-4" /></Button>
                </div>
              </div>
              <div className="mt-3">
                <h1 className="font-display font-bold text-2xl">{profile.display_name || profile.username} {profile.verified && <span className="text-accent">✓</span>}</h1>
                <p className="text-sm text-muted-foreground">@{profile.username}</p>
                {profile.bio && <p className="mt-2 text-sm">{profile.bio}</p>}
              </div>
              <div className="mt-4 flex gap-6 text-sm">
                <div><b>{lvl?.level ?? 1}</b> <span className="text-muted-foreground">Level</span></div>
                <div><b>{nFmt(profile.xp)}</b> <span className="text-muted-foreground">XP</span></div>
                <div><b>{nFmt(counts?.followers ?? 0)}</b> <span className="text-muted-foreground">Followers</span></div>
                <div><b>{nFmt(counts?.following ?? 0)}</b> <span className="text-muted-foreground">Following</span></div>
              </div>
            </div>
          </div>
          <h2 className="font-display font-bold text-xl">Posts</h2>
          {posts?.length ? (
            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{posts.map(p => <PostCard key={p.id} post={p} />)}</div>
          ) : (
            <div className="glass rounded-3xl p-10 text-center text-muted-foreground">No posts yet.</div>
          )}
        </div>
      )}
    </AppShell>
  );
}
