import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { MapPin, Share2, Bookmark, Flag, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { AppShell } from "@/components/AppShell";
import { VoteButton } from "@/components/VoteButton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { timeAgo } from "@/lib/format";

export const Route = createFileRoute("/post/$id")({
  head: () => ({ meta: [{ title: "Location — KHY YA" }] }),
  component: PostDetail,
});

type Post = {
  id: string; title: string; description: string | null; cover_url: string | null;
  location_name: string | null; city: string | null; country: string | null;
  vote_count: number; comment_count: number; tags: string[] | null;
  latitude: number | null; longitude: number | null; created_at: string;
  author_id: string;
  author: { id: string; username: string; avatar_url: string | null; display_name: string | null } | null;
  category: { name: string; icon: string | null } | null;
  images: { url: string }[];
};

function PostDetail() {
  const { id } = Route.useParams();
  const nav = useNavigate();
  const { user, isAdmin } = useAuth();
  const [comment, setComment] = useState("");
  const [bookmarked, setBookmarked] = useState(false);

  const { data: post, isLoading, refetch } = useQuery({
    queryKey: ["post", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("posts")
        .select("id,title,description,cover_url,location_name,city,country,vote_count,comment_count,tags,latitude,longitude,created_at,author_id,author:profiles!posts_author_profile_fkey(id,username,avatar_url,display_name),category:categories(name,icon),images:post_images(url)")
        .eq("id", id).maybeSingle();
      if (error) throw error;
      return data as unknown as Post | null;
    },
  });

  const { data: comments, refetch: refetchC } = useQuery({
    queryKey: ["comments", id],
    queryFn: async () => (await supabase.from("comments").select("id,body,created_at,author_id,author:profiles!comments_author_profile_fkey(username,avatar_url)").eq("post_id", id).order("created_at", { ascending: false }).limit(100)).data ?? [],
  });

  useEffect(() => {
    if (!user) return;
    supabase.from("bookmarks").select("post_id").eq("post_id", id).eq("user_id", user.id).maybeSingle()
      .then(({ data }) => setBookmarked(!!data));
  }, [id, user]);

  const toggleBookmark = async () => {
    if (!user) { nav({ to: "/auth" }); return; }
    if (bookmarked) {
      await supabase.from("bookmarks").delete().eq("post_id", id).eq("user_id", user.id);
      setBookmarked(false);
    } else {
      await supabase.from("bookmarks").insert({ post_id: id, user_id: user.id });
      setBookmarked(true);
    }
  };

  const share = async () => {
    const url = window.location.href;
    if (navigator.share) { try { await navigator.share({ url, title: post?.title }); } catch { /* ignore */ } }
    else { await navigator.clipboard.writeText(url); toast.success("Link copied"); }
  };

  const report = async () => {
    if (!user) return nav({ to: "/auth" });
    const reason = prompt("Report reason: spam, abuse, fake, copyright, duplicate?");
    if (!reason) return;
    await supabase.from("reports").insert({ reporter_id: user.id, post_id: id, reason });
    toast.success("Report submitted");
  };

  const del = async () => {
    if (!confirm("Delete this post?")) return;
    await supabase.from("posts").delete().eq("id", id);
    toast.success("Deleted"); nav({ to: "/explore" });
  };

  const postComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return nav({ to: "/auth" });
    if (!comment.trim()) return;
    const { error } = await supabase.from("comments").insert({ post_id: id, author_id: user.id, body: comment.trim() });
    if (error) toast.error(error.message);
    else { setComment(""); refetchC(); refetch(); }
  };

  return (
    <AppShell>
      {isLoading ? (
        <div className="max-w-3xl mx-auto space-y-4"><Skeleton className="h-96 rounded-3xl" /><Skeleton className="h-40 rounded-3xl" /></div>
      ) : !post ? (
        <div className="glass rounded-3xl p-10 text-center">Post not found.</div>
      ) : (
        <motion.article initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl mx-auto space-y-6">
          {post.cover_url && (
            <div className="rounded-3xl overflow-hidden glass">
              <img src={post.cover_url} alt={post.title} className="w-full max-h-[560px] object-cover" />
            </div>
          )}
          {post.images?.length > 1 && (
            <div className="flex gap-2 overflow-x-auto no-scrollbar">
              {post.images.map((im, i) => <img key={i} src={im.url} alt="" className="h-24 rounded-xl" />)}
            </div>
          )}
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-2">
              {post.category && <Badge className="bg-primary/20 text-primary border-primary/40">{post.category.icon} {post.category.name}</Badge>}
              {post.tags?.map(t => <Badge key={t} variant="secondary">#{t}</Badge>)}
            </div>
            <h1 className="font-display font-bold text-3xl md:text-4xl leading-tight">{post.title}</h1>
            {(post.location_name || post.city) && (
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground mt-2">
                <MapPin className="size-4" />{[post.location_name, post.city, post.country].filter(Boolean).join(", ")}
              </div>
            )}
          </div>
          {post.author && (
            <div className="flex items-center justify-between">
              <Link to="/u/$username" params={{ username: post.author.username }} className="flex items-center gap-3">
                <Avatar><AvatarImage src={post.author.avatar_url ?? undefined} /><AvatarFallback className="bg-primary/20 text-primary">{post.author.username.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                <div><div className="font-medium">@{post.author.username}</div><div className="text-xs text-muted-foreground">{timeAgo(post.created_at)}</div></div>
              </Link>
              <div className="flex gap-2">
                <VoteButton postId={post.id} initialCount={post.vote_count} size="lg" />
              </div>
            </div>
          )}
          {post.description && <p className="text-lg leading-relaxed whitespace-pre-wrap">{post.description}</p>}

          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" onClick={toggleBookmark} className={bookmarked ? "border-primary text-primary" : ""}><Bookmark className={`size-4 mr-1 ${bookmarked ? "fill-primary" : ""}`} /> {bookmarked ? "Saved" : "Save"}</Button>
            <Button variant="outline" onClick={share}><Share2 className="size-4 mr-1" /> Share</Button>
            <Button variant="ghost" onClick={report}><Flag className="size-4 mr-1" /> Report</Button>
            {(user?.id === post.author_id || isAdmin) && <Button variant="ghost" onClick={del} className="text-destructive"><Trash2 className="size-4 mr-1" /> Delete</Button>}
          </div>

          <div className="glass rounded-3xl p-6 space-y-4">
            <h2 className="font-display font-bold text-lg">Comments ({post.comment_count})</h2>
            <form onSubmit={postComment} className="flex gap-2">
              <Textarea value={comment} onChange={e => setComment(e.target.value)} placeholder={user ? "Share your thoughts…" : "Sign in to comment"} rows={2} maxLength={2000} disabled={!user} />
              <Button type="submit" className="gradient-brand text-white" disabled={!user || !comment.trim()}>Post</Button>
            </form>
            <div className="space-y-3">
              {(comments ?? []).map((c: { id: string; body: string; created_at: string; author: { username: string; avatar_url: string | null } | null }) => (
                <div key={c.id} className="flex gap-3">
                  <Avatar className="size-8"><AvatarImage src={c.author?.avatar_url ?? undefined} /><AvatarFallback className="text-xs">{c.author?.username?.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                  <div className="flex-1"><div className="text-sm"><b>@{c.author?.username}</b> <span className="text-xs text-muted-foreground">· {timeAgo(c.created_at)}</span></div><p className="text-sm mt-0.5">{c.body}</p></div>
                </div>
              ))}
            </div>
          </div>
        </motion.article>
      )}
    </AppShell>
  );
}
