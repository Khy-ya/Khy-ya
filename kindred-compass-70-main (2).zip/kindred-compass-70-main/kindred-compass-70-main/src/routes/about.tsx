import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
export const Route = createFileRoute("/about")({
  head: () => ({ meta: [{ title: "About — KHY YA" }, { name: "description", content: "About KHY YA — the community-voted location platform." }] }),
  component: () => (
    <AppShell>
      <div className="max-w-2xl prose prose-invert">
        <h1 className="font-display font-bold text-4xl">About KHY YA</h1>
        <p className="mt-4 text-lg text-muted-foreground">KHY YA is a social platform where explorers share the most stunning places on Earth — with real screenshot proof — and the community votes for the best.</p>
        <p className="mt-4 text-muted-foreground">Every day we crown a winner. Every week, a new champion. Every month, legends are made. Along the way you'll earn XP, coins, and rare achievements that mark you as a true explorer.</p>
        <p className="mt-4 text-muted-foreground">Built with love by <span className="text-gradient font-semibold">Abhijeet Majik</span>. 100% free, forever.</p>
      </div>
    </AppShell>
  ),
});
