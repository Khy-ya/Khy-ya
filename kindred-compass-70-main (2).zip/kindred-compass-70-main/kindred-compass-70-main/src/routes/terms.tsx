import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
export const Route = createFileRoute("/terms")({
  head: () => ({ meta: [{ title: "Terms — KHY YA" }] }),
  component: () => (
    <AppShell>
      <div className="max-w-2xl space-y-4 text-sm text-muted-foreground">
        <h1 className="font-display font-bold text-3xl text-foreground">Terms and Conditions</h1>
        <p>By using KHY YA you agree to these terms.</p>
        <h2 className="text-foreground font-display font-bold text-lg mt-6">Your account</h2>
        <p>You are responsible for what you post. Do not upload content you don't own, illegal content, spam, or harassment.</p>
        <h2 className="text-foreground font-display font-bold text-lg mt-6">Location proof</h2>
        <p>Screenshots must actually depict the location you claim. Fake or misleading posts may be removed and your account suspended.</p>
        <h2 className="text-foreground font-display font-bold text-lg mt-6">Votes</h2>
        <p>One vote per user per post. Vote manipulation, bots, or duplicate accounts result in bans and forfeited XP.</p>
        <h2 className="text-foreground font-display font-bold text-lg mt-6">Termination</h2>
        <p>We can suspend accounts that violate these terms. You can delete your account any time.</p>
      </div>
    </AppShell>
  ),
});
