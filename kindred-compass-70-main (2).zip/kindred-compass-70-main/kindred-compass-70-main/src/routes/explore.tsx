import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { PostCard, type PostCardData } from "@/components/PostCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/explore")({
  head: () => ({ meta: [{ title: "Explore — KHY YA" }, { name: "description", content: "Discover incredible locations from the KHY YA community." }] }),
  component: Explore,
});

function Explore() {
  const [cat, setCat] = useState<string | null>(null);
  const { data: cats } = useQuery({ queryKey: ["categories"], queryFn: async () => (await supabase.from("categories").select("id,name,icon,color").order("sort_order")).data ?? [] });
  const { data: posts, isLoading } = useQuery({
    queryKey: ["explore", cat],
    queryFn: async () => {
      let q = supabase.from("posts").select("id,title,description,cover_url,location_name,city,country,vote_count,comment_count,created_at,tags,author:profiles!posts_author_profile_fkey(id,username,avatar_url,display_name),category:categories(name,color,icon)").eq("status", "published").order("created_at", { ascending: false }).limit(50);
      if (cat) q = q.eq("category_id", cat);
      return (await q).data as unknown as PostCardData[] ?? [];
    },
  });
  return (
    <AppShell>
      <div className="mb-6">
        <h1 className="font-display font-bold text-3xl">Explore</h1>
        <p className="text-muted-foreground text-sm mt-1">Fresh finds from around the world</p>
      </div>
      <div className="flex gap-2 flex-wrap mb-6">
        <Badge onClick={() => setCat(null)} className={`cursor-pointer ${!cat ? "gradient-brand text-white" : "bg-muted"}`}>All</Badge>
        {(cats ?? []).map(c => (
          <Badge key={c.id} onClick={() => setCat(c.id)} className={`cursor-pointer ${cat === c.id ? "gradient-brand text-white" : "bg-muted text-foreground hover:bg-muted/70"}`}>
            {c.icon} {c.name}
          </Badge>
        ))}
      </div>
      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-80 rounded-3xl" />)}</div>
      ) : posts?.length ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{posts.map(p => <PostCard key={p.id} post={p} />)}</div>
      ) : (
        <div className="glass rounded-3xl p-10 text-center text-muted-foreground">No locations here yet.</div>
      )}
    </AppShell>
  );
}
