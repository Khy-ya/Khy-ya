import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const QA = [
  ["How do I post a location?", "Sign in, tap Post, upload a screenshot, pin it on the map, and publish."],
  ["Can I vote on my own posts?", "No — one vote per user, and never on your own posts."],
  ["How are leaderboards calculated?", "Automatically, based on votes in the selected time window (daily, weekly, monthly, all-time)."],
  ["What's XP for?", "XP raises your level and unlocks achievements. Coins are for the reward store."],
  ["Is KHY YA really free?", "Yes — free forever. No paid APIs, no ads."],
  ["How do I report a bad post?", "Open the post, tap Report, and pick a reason. Moderators review reports daily."],
];

export const Route = createFileRoute("/faq")({
  head: () => ({ meta: [{ title: "FAQ — KHY YA" }] }),
  component: () => (
    <AppShell>
      <h1 className="font-display font-bold text-3xl mb-6">Frequently asked questions</h1>
      <div className="max-w-2xl glass rounded-3xl p-4">
        <Accordion type="single" collapsible>
          {QA.map(([q, a], i) => (
            <AccordionItem key={i} value={`i-${i}`}>
              <AccordionTrigger className="text-left">{q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </AppShell>
  ),
});
