import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { LifeBuoy, MessageCircle, BookOpen, Shield } from "lucide-react";

export const Route = createFileRoute("/help")({
  head: () => ({ meta: [{ title: "Help Center — KHY YA" }] }),
  component: () => (
    <AppShell>
      <div className="mb-6 flex items-center gap-3">
        <LifeBuoy className="size-8 text-accent" />
        <div><h1 className="font-display font-bold text-3xl">Help Center</h1><p className="text-muted-foreground text-sm">Everything you need to know</p></div>
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        <Link to="/faq" className="glass rounded-3xl p-6 hover-lift"><BookOpen className="size-6 text-primary mb-2" /><h3 className="font-display font-bold">FAQ</h3><p className="text-sm text-muted-foreground mt-1">Common questions & quick answers</p></Link>
        <Link to="/contact" className="glass rounded-3xl p-6 hover-lift"><MessageCircle className="size-6 text-primary mb-2" /><h3 className="font-display font-bold">Contact us</h3><p className="text-sm text-muted-foreground mt-1">Reach out to the KHY YA team</p></Link>
        <Link to="/privacy" className="glass rounded-3xl p-6 hover-lift"><Shield className="size-6 text-primary mb-2" /><h3 className="font-display font-bold">Privacy & Safety</h3><p className="text-sm text-muted-foreground mt-1">Your data, your rules</p></Link>
      </div>
    </AppShell>
  ),
});
