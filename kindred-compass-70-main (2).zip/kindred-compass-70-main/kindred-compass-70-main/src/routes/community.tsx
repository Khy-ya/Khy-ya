import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Megaphone } from "lucide-react";
import { timeAgo } from "@/lib/format";

export const Route = createFileRoute("/community")({
  head: () => ({ meta: [{ title: "Community — KHY YA" }] }),
  component: Community,
});

function Community() {
  const { data } = useQuery({ queryKey: ["announcements"], queryFn: async () => (await supabase.from("announcements").select("*").order("created_at", { ascending: false })).data ?? [] });
  return (
    <AppShell>
      <div className="mb-6 flex items-center gap-3">
        <Megaphone className="size-8 text-primary" />
        <div><h1 className="font-display font-bold text-3xl">Community</h1><p className="text-muted-foreground text-sm">Announcements & updates from the KHY YA team</p></div>
      </div>
      <div className="space-y-3 max-w-3xl">
        {(data ?? []).map(a => (
          <div key={a.id} className="glass rounded-3xl p-6">
            <div className="text-xs text-muted-foreground">{timeAgo(a.created_at)}</div>
            <h2 className="font-display font-bold text-xl mt-1">{a.title}</h2>
            <p className="mt-2 text-sm whitespace-pre-wrap">{a.body}</p>
          </div>
        ))}
        {data && !data.length && <div className="glass rounded-3xl p-10 text-center text-muted-foreground">No announcements yet.</div>}
      </div>
    </AppShell>
  );
}
