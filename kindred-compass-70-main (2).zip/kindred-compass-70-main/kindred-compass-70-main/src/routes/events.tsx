import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { Calendar } from "lucide-react";

export const Route = createFileRoute("/events")({
  head: () => ({ meta: [{ title: "Events — KHY YA" }] }),
  component: Events,
});

const EVENTS = [
  { name: "Weekend of Waterfalls", when: "Every Saturday", desc: "Post a waterfall — top 3 win 500 coins each." },
  { name: "Hidden Gems Week", when: "First week of the month", desc: "Only lesser-known spots. 2× XP on all votes." },
  { name: "Global Sunset Hour", when: "Fridays 6pm local", desc: "Share a sunset from your city." },
  { name: "Street Food Frenzy", when: "Monthly", desc: "Food category posts get bonus visibility." },
];

function Events() {
  return (
    <AppShell>
      <div className="mb-6 flex items-center gap-3">
        <Calendar className="size-8 text-accent" />
        <div><h1 className="font-display font-bold text-3xl">Events</h1><p className="text-muted-foreground text-sm">Themed community events</p></div>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {EVENTS.map(e => (
          <div key={e.name} className="glass rounded-3xl p-6 hover-lift">
            <div className="text-xs text-accent font-medium">{e.when}</div>
            <h2 className="font-display font-bold text-xl mt-1">{e.name}</h2>
            <p className="text-sm text-muted-foreground mt-2">{e.desc}</p>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
