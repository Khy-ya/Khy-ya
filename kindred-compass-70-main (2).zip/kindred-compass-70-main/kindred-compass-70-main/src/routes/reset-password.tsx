import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [{ title: "Reset password — KHY YA" }, { name: "robots", content: "noindex" }] }),
  component: ResetPassword,
});

function ResetPassword() {
  const nav = useNavigate();
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Supabase auto-processes the recovery hash and fires PASSWORD_RECOVERY
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") setReady(true);
    });
    supabase.auth.getSession().then(({ data }) => { if (data.session) setReady(true); });
    return () => sub.subscription.unsubscribe();
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try { z.string().min(8).max(72).parse(password); } catch { toast.error("Password must be at least 8 characters"); return; }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) toast.error(error.message);
    else { toast.success("Password updated"); nav({ to: "/home" }); }
  };

  return (
    <div className="min-h-screen grid place-items-center px-4 bg-background text-foreground">
      <form onSubmit={submit} className="w-full max-w-sm glass rounded-3xl p-8 space-y-4">
        <h1 className="font-display font-bold text-2xl">Set a new password</h1>
        {!ready ? (
          <p className="text-sm text-muted-foreground">Open the reset link from your email to continue.</p>
        ) : (
          <>
            <div>
              <Label htmlFor="p">New password</Label>
              <Input id="p" type="password" value={password} onChange={e => setPassword(e.target.value)} minLength={8} required />
            </div>
            <Button type="submit" className="w-full gradient-brand text-white" disabled={loading}>
              {loading && <Loader2 className="size-4 animate-spin mr-2" />} Update password
            </Button>
          </>
        )}
      </form>
    </div>
  );
}
