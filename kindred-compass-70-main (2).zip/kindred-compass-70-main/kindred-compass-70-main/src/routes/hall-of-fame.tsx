import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Landmark } from "lucide-react";
import { nFmt } from "@/lib/format";

export const Route = createFileRoute("/hall-of-fame")({
  head: () => ({ meta: [{ title: "Hall of Fame — KHY YA" }, { name: "description", content: "The top explorers of all time on KHY YA." }] }),
  component: HallOfFame,
});

function HallOfFame() {
  const { data, isLoading } = useQuery({
    queryKey: ["top-users"],
    queryFn: async () => (await supabase.from("top_users").select("*").limit(100)).data ?? [],
  });
  return (
    <AppShell>
      <div className="mb-6 flex items-center gap-3">
        <Landmark className="size-8 text-accent" />
        <div><h1 className="font-display font-bold text-3xl">Hall of Fame</h1><p className="text-muted-foreground text-sm">The all-time greatest explorers</p></div>
      </div>
      {isLoading ? <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-2xl" />)}</div> : (
        <div className="space-y-2">
          {(data ?? []).map((u, i) => (
            <Link key={u.id} to="/u/$username" params={{ username: u.username }} className="glass rounded-2xl p-3 flex items-center gap-4 hover-lift">
              <div className="w-8 text-center font-mono text-muted-foreground">{i + 1}</div>
              <Avatar><AvatarImage src={u.avatar_url ?? undefined} /><AvatarFallback className="bg-primary/20 text-primary">{u.username?.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
              <div className="flex-1 min-w-0"><div className="font-medium">@{u.username}</div><div className="text-xs text-muted-foreground">{u.posts_count} posts · {u.followers_count} followers</div></div>
              <div className="text-right"><div className="font-display font-bold text-gradient">{nFmt(u.xp)}</div><div className="text-xs text-muted-foreground">XP</div></div>
            </Link>
          ))}
        </div>
      )}
    </AppShell>
  );
}
