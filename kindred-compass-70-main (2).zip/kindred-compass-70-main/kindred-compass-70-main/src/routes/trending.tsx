import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { PostCard, type PostCardData } from "@/components/PostCard";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/trending")({
  head: () => ({ meta: [{ title: "Trending — KHY YA" }, { name: "description", content: "The hottest locations on KHY YA right now." }] }),
  component: Trending,
});

function Trending() {
  const { data, isLoading } = useQuery({
    queryKey: ["trending"],
    queryFn: async () => (await supabase.from("posts").select("id,title,description,cover_url,location_name,city,country,vote_count,comment_count,created_at,tags,author:profiles!posts_author_profile_fkey(id,username,avatar_url,display_name),category:categories(name,color,icon)").eq("status", "published").order("vote_count", { ascending: false }).order("created_at", { ascending: false }).limit(30)).data as unknown as PostCardData[] ?? [],
  });
  return (
    <AppShell>
      <div className="mb-6">
        <h1 className="font-display font-bold text-3xl">🔥 Trending</h1>
        <p className="text-muted-foreground text-sm mt-1">Most voted, all time</p>
      </div>
      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-80 rounded-3xl" />)}</div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{(data ?? []).map(p => <PostCard key={p.id} post={p} />)}</div>
      )}
    </AppShell>
  );
}
