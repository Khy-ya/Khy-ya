import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { motion } from "framer-motion";

export const Route = createFileRoute("/categories")({
  head: () => ({ meta: [{ title: "Categories — KHY YA" }] }),
  component: Categories,
});

function Categories() {
  const { data: cats } = useQuery({ queryKey: ["cats-all"], queryFn: async () => (await supabase.from("categories").select("*").order("sort_order")).data ?? [] });
  return (
    <AppShell>
      <h1 className="font-display font-bold text-3xl mb-6">Categories</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {(cats ?? []).map((c, i) => (
          <motion.div key={c.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
            <Link to="/explore" className="glass rounded-3xl p-6 block text-center hover-lift">
              <div className="text-4xl">{c.icon}</div>
              <div className="mt-2 font-display font-bold">{c.name}</div>
            </Link>
          </motion.div>
        ))}
      </div>
    </AppShell>
  );
}
