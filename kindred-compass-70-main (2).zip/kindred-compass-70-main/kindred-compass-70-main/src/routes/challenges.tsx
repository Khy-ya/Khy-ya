import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Target } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/challenges")({
  head: () => ({ meta: [{ title: "Challenges — KHY YA" }] }),
  component: Challenges,
});

function Challenges() {
  const { data } = useQuery({ queryKey: ["missions"], queryFn: async () => (await supabase.from("missions").select("*").eq("active", true)).data ?? [] });
  return (
    <AppShell>
      <div className="mb-6 flex items-center gap-3">
        <Target className="size-8 text-primary" />
        <div><h1 className="font-display font-bold text-3xl">Challenges</h1><p className="text-muted-foreground text-sm">Daily missions & long-term goals</p></div>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {(data ?? []).map(m => (
          <div key={m.id} className="glass rounded-3xl p-6">
            <div className="font-display font-bold text-lg">{m.title}</div>
            <p className="text-sm text-muted-foreground mt-1">{m.description}</p>
            <div className="mt-4 flex items-center gap-3">
              <Progress value={0} className="flex-1" />
              <span className="text-xs text-muted-foreground">0 / {m.goal}</span>
            </div>
            <div className="mt-3 text-xs text-accent">Reward: +{m.xp_reward} XP · +{m.coin_reward} coins</div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
