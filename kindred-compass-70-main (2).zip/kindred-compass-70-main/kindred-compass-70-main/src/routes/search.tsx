import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { PostCard, type PostCardData } from "@/components/PostCard";
import { Input } from "@/components/ui/input";
import { Search as SearchIcon } from "lucide-react";

export const Route = createFileRoute("/search")({
  head: () => ({ meta: [{ title: "Search — KHY YA" }] }),
  component: SearchPage,
});

function SearchPage() {
  const [q, setQ] = useState("");
  const [posts, setPosts] = useState<PostCardData[]>([]);
  const [users, setUsers] = useState<{ id: string; username: string; avatar_url: string | null; display_name: string | null }[]>([]);

  const run = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    const like = `%${q}%`;
    const [{ data: p }, { data: u }] = await Promise.all([
      supabase.from("posts").select("id,title,description,cover_url,location_name,city,country,vote_count,comment_count,created_at,tags,author:profiles!posts_author_profile_fkey(id,username,avatar_url,display_name),category:categories(name,color,icon)").or(`title.ilike.${like},description.ilike.${like},location_name.ilike.${like},city.ilike.${like}`).eq("status", "published").limit(30),
      supabase.from("profiles").select("id,username,avatar_url,display_name").or(`username.ilike.${like},display_name.ilike.${like}`).limit(20),
    ]);
    setPosts((p as unknown as PostCardData[]) ?? []);
    setUsers(u ?? []);
  };

  return (
    <AppShell>
      <form onSubmit={run} className="glass rounded-full flex items-center gap-2 px-4 py-2 mb-8 max-w-2xl mx-auto">
        <SearchIcon className="size-4 text-muted-foreground" />
        <Input value={q} onChange={e => setQ(e.target.value)} placeholder="Search locations, users, tags…" className="border-0 bg-transparent focus-visible:ring-0" />
      </form>
      {users.length > 0 && (
        <section className="mb-8">
          <h2 className="font-display font-bold text-lg mb-3">Users</h2>
          <div className="flex gap-3 flex-wrap">
            {users.map(u => (
              <a key={u.id} href={`/u/${u.username}`} className="glass rounded-2xl p-3 flex items-center gap-3 hover-lift">
                <div className="size-10 rounded-full gradient-brand grid place-items-center text-white font-bold">{u.username[0].toUpperCase()}</div>
                <div><div className="font-medium">@{u.username}</div><div className="text-xs text-muted-foreground">{u.display_name}</div></div>
              </a>
            ))}
          </div>
        </section>
      )}
      {posts.length > 0 && (
        <section>
          <h2 className="font-display font-bold text-lg mb-3">Locations</h2>
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{posts.map(p => <PostCard key={p.id} post={p} />)}</div>
        </section>
      )}
      {!posts.length && !users.length && q && <div className="glass rounded-3xl p-10 text-center text-muted-foreground">No matches for "{q}"</div>}
    </AppShell>
  );
}
