import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

const BASE_URL = "";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries = [
          { path: "/", priority: "1.0" },
          { path: "/explore", priority: "0.9" },
          { path: "/trending", priority: "0.9" },
          { path: "/leaderboards", priority: "0.9" },
          { path: "/hall-of-fame", priority: "0.8" },
          { path: "/map", priority: "0.8" },
          { path: "/categories", priority: "0.7" },
          { path: "/community", priority: "0.6" },
          { path: "/events", priority: "0.6" },
          { path: "/challenges", priority: "0.6" },
          { path: "/about", priority: "0.5" },
          { path: "/faq", priority: "0.5" },
          { path: "/help", priority: "0.5" },
          { path: "/contact", priority: "0.5" },
          { path: "/privacy", priority: "0.3" },
          { path: "/terms", priority: "0.3" },
        ];
        const urls = entries.map(e => `  <url><loc>${BASE_URL}${e.path}</loc><changefreq>weekly</changefreq><priority>${e.priority}</priority></url>`).join("\n");
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`;
        return new Response(xml, { headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" } });
      },
    },
  },
});
