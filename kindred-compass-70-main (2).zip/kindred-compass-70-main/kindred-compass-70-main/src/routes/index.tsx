import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { MapPin, Trophy, Flame, Camera, Sparkles, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "KHY YA — Share and vote for the world's best locations" },
      { name: "description", content: "Upload stunning locations with proof, vote for the best, climb daily leaderboards and unlock XP, coins and rare badges." },
    ],
  }),
  component: Landing,
});

function Landing() {
  const { user } = useAuth();
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <nav className="sticky top-0 z-40 glass border-b border-border/60">
        <div className="mx-auto max-w-7xl px-4 h-14 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="size-8 rounded-xl gradient-brand grid place-items-center text-white font-bold">K</div>
            <span className="font-display font-bold text-lg text-gradient">KHY YA</span>
          </Link>
          <div className="hidden md:flex items-center gap-6 text-sm text-muted-foreground">
            <Link to="/explore" className="hover:text-foreground">Explore</Link>
            <Link to="/leaderboards" className="hover:text-foreground">Leaderboards</Link>
            <Link to="/about" className="hover:text-foreground">About</Link>
          </div>
          <div className="flex items-center gap-2">
            {user ? (
              <Link to="/home"><Button className="gradient-brand text-white">Open app</Button></Link>
            ) : (
              <>
                <Link to="/auth"><Button variant="ghost" size="sm">Sign in</Button></Link>
                <Link to="/auth"><Button size="sm" className="gradient-brand text-white">Get started</Button></Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="gradient-hero relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 pt-20 pb-24 lg:pt-32 lg:pb-40 text-center relative">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs mb-6">
              <Sparkles className="size-3 text-accent" />
              <span className="text-muted-foreground">Live daily leaderboards · earn XP + coins</span>
            </div>
            <h1 className="font-display font-bold text-5xl md:text-7xl lg:text-8xl leading-[0.95] tracking-tight">
              Share the <span className="text-gradient">most stunning</span><br />places on Earth.
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-lg text-muted-foreground">
              Upload a location, prove it with a screenshot, and let the world vote. Climb the daily, weekly, and monthly boards. Unlock badges. Become a legend.
            </p>
            <div className="mt-10 flex flex-wrap gap-3 justify-center">
              <Link to={user ? "/create" : "/auth"}>
                <Button size="lg" className="gradient-brand text-white glow-primary h-12 px-6 text-base gap-2">
                  Post a location <ArrowRight className="size-4" />
                </Button>
              </Link>
              <Link to="/explore">
                <Button size="lg" variant="outline" className="h-12 px-6 text-base border-border">
                  Explore first
                </Button>
              </Link>
            </div>
          </motion.div>

          {/* Feature tiles */}
          <div className="mt-20 grid md:grid-cols-3 gap-4 text-left">
            {[
              { icon: Camera, title: "Upload with proof", desc: "Attach a screenshot or photo. GPS-tag it on the map." },
              { icon: Flame, title: "Vote for the best", desc: "One vote per user. Live counters. Fair rankings." },
              { icon: Trophy, title: "Climb every day", desc: "Daily, weekly, monthly, yearly and global boards refresh automatically." },
            ].map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 + i * 0.08 }}
                className="glass rounded-3xl p-6 hover-lift"
              >
                <div className="size-11 rounded-2xl gradient-brand grid place-items-center text-white mb-4">
                  <f.icon className="size-5" />
                </div>
                <h3 className="font-display font-bold text-lg">{f.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-t border-border/60">
        <div className="mx-auto max-w-7xl px-4 py-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[
            { k: "10+", v: "Categories" },
            { k: "5", v: "Leaderboard tiers" },
            { k: "16", v: "Achievements" },
            { k: "∞", v: "Places to find" },
          ].map(s => (
            <div key={s.v}>
              <div className="text-4xl font-display font-bold text-gradient">{s.k}</div>
              <div className="text-sm text-muted-foreground mt-1">{s.v}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border/60">
        <div className="mx-auto max-w-4xl px-4 py-24 text-center">
          <MapPin className="size-10 mx-auto text-accent mb-4" />
          <h2 className="font-display font-bold text-3xl md:text-5xl">Your favourite spot deserves a crown.</h2>
          <p className="mt-4 text-muted-foreground">Free forever. Sign up in seconds.</p>
          <Link to={user ? "/home" : "/auth"} className="inline-block mt-8">
            <Button size="lg" className="gradient-brand text-white h-12 px-8 glow-primary">Join KHY YA</Button>
          </Link>
        </div>
      </section>

      <footer className="border-t border-border/60">
        <div className="mx-auto max-w-7xl px-4 py-8 flex flex-col md:flex-row items-center justify-between gap-3 text-sm text-muted-foreground">
          <div>© {new Date().getFullYear()} KHY YA</div>
          <div className="flex gap-4">
            <Link to="/privacy" className="hover:text-foreground">Privacy</Link>
            <Link to="/terms" className="hover:text-foreground">Terms</Link>
            <Link to="/contact" className="hover:text-foreground">Contact</Link>
          </div>
          <div>Created by <span className="text-gradient font-semibold">Abhijeet Majik</span></div>
        </div>
      </footer>
    </div>
  );
}
