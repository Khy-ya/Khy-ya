import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Loader2 } from "lucide-react";
import "leaflet/dist/leaflet.css";

export const Route = createFileRoute("/map")({
  head: () => ({ meta: [{ title: "Map Explorer — KHY YA" }, { name: "description", content: "Explore locations pinned around the world." }] }),
  component: MapExplorer,
});

function MapExplorer() {
  const ref = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let disposed = false;
    (async () => {
      const L = (await import("leaflet")).default;
      // @ts-expect-error internal
      delete L.Icon.Default.prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
        iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
        shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      });
      if (disposed || !ref.current) return;
      const map = L.map(ref.current).setView([20, 0], 2);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap", maxZoom: 19 }).addTo(map);

      const { data } = await supabase.from("posts").select("id,title,latitude,longitude,cover_url,vote_count").eq("status", "published").not("latitude", "is", null).limit(500);
      (data ?? []).forEach(p => {
        if (p.latitude == null || p.longitude == null) return;
        const m = L.marker([p.latitude, p.longitude]).addTo(map);
        m.bindPopup(`<div style="min-width:180px"><b>${p.title}</b><br/>🔥 ${p.vote_count} votes<br/><a href="/post/${p.id}" style="color:#7c3aed">View →</a></div>`);
      });
      setReady(true);
    })();
    return () => { disposed = true; };
  }, []);

  return (
    <AppShell>
      <div className="mb-4">
        <h1 className="font-display font-bold text-3xl">Map Explorer</h1>
        <p className="text-muted-foreground text-sm mt-1">Every pin is a location the community has shared.</p>
      </div>
      <div ref={ref} className="w-full h-[70vh] rounded-3xl overflow-hidden border border-border relative">
        {!ready && <div className="absolute inset-0 grid place-items-center bg-muted"><Loader2 className="animate-spin" /></div>}
      </div>
    </AppShell>
  );
}
