# KHY YA — Build Plan

A location-sharing social platform with voting, leaderboards, and gamification. Full spec is ~50+ pages — I'll ship in phases, each phase fully functional before moving on.

## Stack

- **Frontend**: TanStack Start (React 19) + Tailwind v4 + Framer Motion + Leaflet
- **Backend**: Lovable Cloud (Postgres + Auth + Realtime + Storage) — replaces Express/MongoDB/Socket.io
- **Auth**: Email/password + Google OAuth
- **Admin**: `abhijeetmajik@gmail.com` auto-promoted to admin on verified signup (secure — no shared password)

## Design system — "Neon Explorer"

- Background `#0B0F1A`, surfaces `#1A1F2E`, primary `#7C3AED` (violet), accent `#22D3EE` (cyan)
- Glassmorphism cards, neon glow shadows, rounded-2xl, dark-first with light mode toggle
- Framer Motion page/element animations, skeleton loaders, toast notifications

## Phase 1 — Foundation (this turn)

1. Enable Lovable Cloud
2. Design system in `src/styles.css` (Neon Explorer tokens, glass utilities, glow shadows)
3. Database schema + RLS + grants:
   - `profiles`, `user_roles` (with `has_role` fn, admin-email trigger)
   - `categories`, `posts`, `post_images`, `votes`, `comments`, `follows`
   - `notifications`, `bookmarks`, `saves`, `reports`
   - `xp_events`, `achievements`, `user_achievements`, `login_streaks`, `daily_rewards`
   - `challenges`, `missions`, `user_missions`
   - Storage buckets: `avatars`, `covers`, `post-images`
4. Auth flow: `/auth` (signup/login/google), `/auth/forgot`, `/reset-password`, `_authenticated` gate
5. App shell: sidebar + top nav + mobile bottom-tab, notifications bell, search, avatar menu, dark/light toggle
6. Landing page (marketing), Home feed, Create Post (with Leaflet map picker + GPS + image upload)
7. Post detail + voting (one vote/user, live counter via realtime)
8. User profile + Edit profile + Settings
9. Explore + Trending + Search
10. Daily/Weekly/Monthly/Global/Category leaderboards (server-computed views)
11. Notifications (realtime), Bookmarks, Saved posts, Activity
12. Admin dashboard `/admin`: user mgmt, post mgmt, reports, categories, announcements
13. 404, error boundaries, maintenance page, footer with "Created by Abhijeet Majik"

## Phase 2 (next turn) — Social depth

Comments with replies/reactions/mentions, Follow system, Messages (1:1 realtime), Community feed, Share links, Reports moderation queue

## Phase 3 — Gamification depth

XP/Coins/Gems economy, Levels+Prestige, Daily/Weekly/Monthly rewards, Login streaks, Lucky Wheel, Reward Store, Missions engine, 30+ Achievements w/ hidden ones, Hall of Fame, Yearly/City/State/Country leaderboards

## Phase 4 — Extras & polish

Events, Challenges pages, Map Explorer (clustered markers, nearby search, distance filter), Advanced search (filters/suggestions), FAQ/Help/Contact/About/Privacy/Terms, Admin: roles/permissions/moderators/badges/theme/backup/logs/analytics charts

## Security

RLS on every table, `has_role()` security-definer fn, verified-email trigger for admin promotion, rate-limited server fns for voting, HIBP password check, Zod validation, signed upload URLs, XSS-safe rendering, no service role in client.

## Technical notes

- Voting: `unique(user_id, post_id)` + server fn checks; realtime channel per post
- Leaderboards: SQL views (`daily_leaderboard`, etc.) computed from `votes` with time windows
- Points: DB triggers award XP on vote/post/comment; `has_role` and `award_xp` security-definer fns
- Maps: Leaflet + OSM tiles, dynamic import (client-only), no API key
- Realtime: Supabase channels for votes, notifications, messages
- Images: Client-side compression before upload to Storage; public URLs

---

**Reality check**: Phase 1 alone is a large turn. Phases 2–4 will each need their own turn. I'll start Phase 1 immediately after you approve.