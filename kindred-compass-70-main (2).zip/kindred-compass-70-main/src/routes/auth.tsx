import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { z } from "zod";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {  } from "@/integrations/";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const searchSchema = z.object({ mode: z.enum(["signin", "signup"]).optional() });

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({ meta: [{ title: "Sign in — KHY YA" }, { name: "description", content: "Sign in or create your KHY YA account." }] }),
  component: AuthPage,
});

const emailSchema = z.string().trim().email("Enter a valid email").max(255);
const passwordSchema = z.string().min(8, "At least 8 characters").max(72);

function AuthPage() {
  const nav = useNavigate();
  const { mode } = Route.useSearch();
  const [tab, setTab] = useState<"signin" | "signup">(mode === "signup" ? "signup" : "signin");
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");

  const google = async () => {
    setLoading(true);
    const res = await .auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/home" });
    if (res.error) { toast.error("Google sign-in failed"); setLoading(false); return; }
    if (res.redirected) return;
    nav({ to: "/home" });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      emailSchema.parse(email);
      passwordSchema.parse(password);
    } catch (err) {
      if (err instanceof z.ZodError) toast.error(err.errors[0].message);
      return;
    }
    setLoading(true);
    try {
      if (tab === "signup") {
        const uname = username.trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
        if (uname.length < 3) { toast.error("Username must be 3+ letters/numbers"); setLoading(false); return; }
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { emailRedirectTo: window.location.origin + "/home", data: { username: uname, display_name: uname } },
        });
        if (error) throw error;
        toast.success("Account created — check your email to confirm.");
        nav({ to: "/home" });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Welcome back!");
        nav({ to: "/home" });
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Auth failed");
    } finally { setLoading(false); }
  };

  const forgot = async () => {
    try { emailSchema.parse(email); } catch { toast.error("Enter your email above first"); return; }
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin + "/reset-password" });
    if (error) toast.error(error.message);
    else toast.success("Reset link sent to your email.");
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background text-foreground">
      <div className="hidden lg:flex gradient-hero relative overflow-hidden items-center justify-center p-12">
        <div className="max-w-md">
          <Link to="/" className="inline-flex items-center gap-2 mb-8">
            <div className="size-9 rounded-xl gradient-brand grid place-items-center text-white font-bold">K</div>
            <span className="font-display font-bold text-2xl text-gradient">KHY YA</span>
          </Link>
          <h1 className="font-display font-bold text-4xl leading-tight">Every place has a story.<br />Yours might win today.</h1>
          <p className="mt-4 text-muted-foreground">Upload, vote, and climb the daily leaderboard.</p>
        </div>
      </div>
      <div className="flex items-center justify-center p-6">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm glass rounded-3xl p-8">
          <Link to="/" className="lg:hidden inline-flex items-center gap-2 mb-6">
            <div className="size-8 rounded-xl gradient-brand grid place-items-center text-white font-bold">K</div>
            <span className="font-display font-bold text-lg text-gradient">KHY YA</span>
          </Link>
          <Tabs value={tab} onValueChange={(v) => setTab(v as "signin" | "signup")}>
            <TabsList className="grid grid-cols-2 w-full mb-6">
              <TabsTrigger value="signin">Sign in</TabsTrigger>
              <TabsTrigger value="signup">Create account</TabsTrigger>
            </TabsList>
            <TabsContent value={tab}>
              <Button type="button" variant="outline" className="w-full mb-4 h-11" onClick={google} disabled={loading}>
                <svg viewBox="0 0 48 48" className="size-4 mr-2"><path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/><path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/><path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24c0 3.55.85 6.91 2.34 9.88l7.35-5.7z"/><path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"/></svg>
                Continue with Google
              </Button>
              <div className="relative my-4"><div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border" /></div><div className="relative flex justify-center text-xs"><span className="bg-card px-2 text-muted-foreground">or</span></div></div>
              <form onSubmit={submit} className="space-y-3">
                {tab === "signup" && (
                  <div>
                    <Label htmlFor="u">Username</Label>
                    <Input id="u" value={username} onChange={e => setUsername(e.target.value)} placeholder="explorer" required minLength={3} maxLength={30} />
                  </div>
                )}
                <div>
                  <Label htmlFor="e">Email</Label>
                  <Input id="e" type="email" value={email} onChange={e => setEmail(e.target.value)} required autoComplete="email" />
                </div>
                <div>
                  <Label htmlFor="p">Password</Label>
                  <Input id="p" type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8} autoComplete={tab === "signup" ? "new-password" : "current-password"} />
                </div>
                {tab === "signin" && (
                  <button type="button" onClick={forgot} className="text-xs text-muted-foreground hover:text-primary">Forgot password?</button>
                )}
                <Button type="submit" className="w-full gradient-brand text-white h-11" disabled={loading}>
                  {loading && <Loader2 className="size-4 animate-spin mr-2" />}
                  {tab === "signup" ? "Create account" : "Sign in"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
          <p className="mt-6 text-xs text-center text-muted-foreground">
            By continuing you agree to our <Link to="/terms" className="underline">Terms</Link> and <Link to="/privacy" className="underline">Privacy Policy</Link>.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
